require("dotenv").config();
const axios = require("axios");
const qs = require("querystring");
const moment = require("moment");
const _logger = require("../Logger");

const {
    tenant,
    client_id: clientId,
    client_secret: clientSecret,
    domain,
} = process.env;

// Function to get the access token
const getAccessToken = async () => {
    const tokenUrl = `https://${tenant}.api.${domain}.com/oauth/token`;
    const tokenConfig = {
        method: "post",
        url: tokenUrl,
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        data: qs.stringify({
            grant_type: "client_credentials",
            client_id: clientId,
            client_secret: clientSecret,
        }),
    };

    if (
        !process.env.tokenExpTime ||
        moment(process.env.tokenExpTime) <= moment()
    ) {
        try {
            process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
            const response = await axios(tokenConfig);
            if (response.status !== 200)
                throw new Error(
                    `Unable to authenticate: ${JSON.stringify(response.data)}`
                );
            const newAccessToken = response.data.access_token;
            process.env.accessToken = newAccessToken;
            process.env.tokenExpTime = moment().add(12, "hours");
            console.log(process.env.accessToken);
            _logger.debug(process.env.accessToken)
            return newAccessToken;
        } catch (error) {
            console.error("Error getting access token:", error);
            _logger.error("Error getting access token:", error);
        }
    } else {
        console.log(process.env.accessToken);
        _logger.debug(process.env.accessToken)
        return process.env.accessToken;
    }
};


module.exports = { getAccessToken }