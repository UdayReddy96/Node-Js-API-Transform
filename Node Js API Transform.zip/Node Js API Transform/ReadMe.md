# Running a Node.js Application from Command Prompt

**Author**: Uday Reddy

This guide provides step-by-step instructions to install Node.js and npm on your system and run a Node.js application from the command prompt without using any text editor.

## Installing Node.js and npm

1. **Download Node.js**: 
   - Visit the official Node.js website: [nodejs.org](https://nodejs.org/).
   - Download the appropriate installer for your operating system (Windows, macOS, or Linux).

2. **Install Node.js**:
   - Run the downloaded installer to start the installation process.
   - Follow the prompts in the installation wizard to install Node.js and npm.
   - Check the option to add Node.js to the system PATH during installation for easy command-line access.

3. **Verify Installation**:
   - Open a command prompt (Windows) or terminal (macOS/Linux).
   - Run the following commands to verify Node.js and npm installation:
     ```bash
     node -v
     npm -v
     ```
   - Verify that the version numbers of Node.js and npm are displayed.

## Running the Node.js Application

# Application Setup Guide

Follow these steps to set up and run the Node.js application.

Step 1: Clone or Download the Application

- Clone the repository to your local machine using Git:
  ```bash
  git clone <repository-url>

or

Download the application as a zip file and extract it to your desired location.
Step 2: Navigate to Application Directory
Open your command prompt (Windows) or terminal (macOS/Linux).

Use the cd command to navigate to the directory where your Node.js application is located: cd path/to/your/nodejs/application

Step 3: Install Dependencies
If the application has dependencies specified in package.json, install them using npm: npm install

Step 4: Run the Application
After installing dependencies, run your Node.js application with the following command: npm start

## Additional Notes
  
- **Keep the Command Prompt/Terminal Open**: Keep the command prompt/terminal window open while your Node.js application is running to keep it running.

Sample API URL:
// let url = `https://${tenant}.api.${domain}.com/v3/access-profiles`;
//let url = `https://${tenant}.api.${domain}.com/v3/access-request-approvals/completed`;
// let url = `https://${tenant}.api.${domain}.com/v3/access-request-approvals/pending`;
// let url = `https://${tenant}.api.${domain}.com/v3/access-request-approvals/approval-summary`;
// let url = `https://${tenant}.api.${domain}.com/v3/accounts`;
// let url = `https://${tenant}.api.${domain}.com/v3/campaigns`;
// let url = `https://${tenant}.api.${domain}.com/v3/requestable-objects`;