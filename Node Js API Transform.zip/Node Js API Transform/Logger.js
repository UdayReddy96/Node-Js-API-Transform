/*
Author: Uday Reddy
  This script is used for logging exception and activities info
*/

// Importing winston for logging exception and activities info
const { createLogger, format, transports } = require("winston");
require("winston-daily-rotate-file");
const configLevel = require("./config");

const winston = require("winston");
const { combine, timestamp, json } = winston.format;
// Logger function for error and activity logging
const logger = winston.createLogger({
  transports: [
    new winston.transports.DailyRotateFile({
      filename: "logs/%DATE%.log",
      datePattern: "YYYY-MM-DD",
      level: "silly", // Set level to "silly" to allow all log levels
      zippedArchive: true,
      maxFiles: "14d",
      format: winston.format.json(),
    }),
  ],
});

// Exporting the functions to use in other files
module.exports = logger;
