/*
Author: Uday Reddy
.SYNOPSIS
    config.js is used for Intializing the environmental variables 
DESCRIPTION
    This is the script used for Intializing the environmental variables which can be used through out the application
*/

// Importing path module
const path = require("path");

// Importing dotenv module and specifying the path for .env to intialise env variables
require("dotenv").config({ path: path.resolve(__dirname, "./.env") });

const { tenant, domain, client_id, client_secret, api, MAX_RETRIES, RETRY_INTERVAL, INITIAL_DELAY } = process.env;
const api_type = ["/v3", "/beta"]; // Feel free to modify as per the requirement

module.exports = {
    tenant: tenant,
    client_id: client_id,
    client_secret: client_secret,
    domain: domain,
    api: api,
    api_type: api_type,
    MAX_RETRIES: MAX_RETRIES,
    RETRY_INTERVAL: RETRY_INTERVAL,
    INITIAL_DELAY: INITIAL_DELAY,
    APIS: [
        `${api_type[0]}/access-profiles`,
        `${api_type[0]}/access-request-approvals/completed`,
        `${api_type[0]}/access-request-approvals/pending`,
        `${api_type[0]}/access-request-approvals/approval-summary`,
        `${api_type[0]}/accounts`,
        `${api_type[0]}/campaigns`,
        `${api_type[0]}/requestable-objects`,
        `${api_type[0]}/roles`,
        `${api_type[0]}/sources`,
        `${api_type[0]}/work-items`,
        `${api_type[0]}/sod-policies`,
        `${api_type[0]}/workflows`,
        `${api_type[1]}/entitlements`,
        `${api_type[1]}/identities`,
        `${api_type[1]}/sources`,

    ]
}