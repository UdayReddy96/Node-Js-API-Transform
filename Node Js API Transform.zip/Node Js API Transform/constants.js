/**
 * Author: Uday Reddy
 * @SYNOPSIS
 * constant.js is used for storing all the string constants
 * @DESCRIPTION
 * This is the script used for for storing all the string constants.
 */

module.exports = {

    ten: 10,
    fifty: 50,
}

