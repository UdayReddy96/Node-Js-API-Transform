/* Author: Uday Reddy
 Summary:
  This file contains functions to fetch data from various APIs, process the data, and create PDF reports based on the analysis.*/
const axios = require("axios");
const { getAccessToken } = require("./Token/getToken");
const { processLBI, createLBIPDF } = require("./APIValidation/IdentitiesList");
const { analyzeData, createAccessProfilePdf } = require("./APIValidation/AccessProfile");
const { analyzeARAC, createARCPdf } = require("./APIValidation/ARAC");
const { analyseARAP, createARAPPDF } = require("./APIValidation/ARAP");
const { getTotalARAASSummary, createARAASPdf } = require("./APIValidation/ARAAS");
const { analyseGAL, createGALPdf } = require("./APIValidation/GetAccountList");
const { analyzeGLC, createGLCPdf } = require("./APIValidation/GLC");
const { analyzeReqObjResult, createReqObjResultPdf } = require("./APIValidation/ReqObjResult");
const { analyzeRoles, createRolesResultPdf } = require("./APIValidation/Roles");
const { processData, generatePDF, processLBS, generateSourcePDF } = require("./APIValidation/Sources");
const { analyzeGLWI, generateGLWIPDF } = require("./APIValidation/GLWI");
const { analyzeLSP, generateLSPPDF } = require("./APIValidation/SodPolicies");
const { analyzeLBE, createLBEPDF } = require("./APIValidation/Entitlements");
const { analyzeGLW, createGLWPDF } = require("./APIValidation/Workflows");
const { fetchIdentitiesAndGeneratePdf, generateAuthUserDetailsPDF } = require("./APIValidation/GetAuthUserData")
const { fetchNonEmployeeRecordsAndGeneratePdf, generateNonEmployeeRecordsPDF } = require("./APIValidation/NonEmployeeRecord")
const constant = require("./constants")
const _logger = require("./Logger");
const config = require("./config");
const fs = require('fs');
const { promisify } = require('util');

const mkdirAsync = promisify(fs.mkdir);

require("dotenv").config();

/**
 * Main function to fetch data from APIs and create PDF reports.
 */
const { write } = require('fast-csv');

const fetchDataAndCreatePdf = async () => {
  try {
    const token = await getAccessToken();
    const fetchAndCreatePdfPromises = [];

    for (const api of config.APIS) {
      const allData = await fetchApiData(api, token);
      if (allData.length > 0) {
        const { apiResult, apiVersionResult } = processApiData(api);

        const csvDir = `./csvOutput/v3`;
        if (!fs.existsSync(csvDir)) {
          fs.mkdirSync(csvDir, { recursive: true });
        }

        const csvFileName = api.replace(/[\/\\]/g, '_').replace(/^\//, '');
        const csvFilePath = `${csvDir}/${csvFileName}_data.csv`;

        const writableStream = fs.createWriteStream(csvFilePath);

        // Writing CSV data
        write(allData, { headers: true })
          .transform((row) => {
            // Create a copy of the row to isolate each column's value
            const transformedRow = { ...row };

            // Transforming each column value to flatten nested objects and arrays of objects
            for (const key in transformedRow) {
              if (typeof transformedRow[key] === 'object' && transformedRow[key] !== null && !Array.isArray(transformedRow[key]) && key !== 'attributes') {
                transformedRow[key] = JSON.stringify(transformedRow[key]);
              } else if (Array.isArray(transformedRow[key]) && transformedRow[key].every(elem => typeof elem === 'object' && elem !== null)) {
                transformedRow[key] = JSON.stringify(transformedRow[key]);
              }
            }
            return transformedRow;
          })
          .pipe(writableStream);

        fetchAndCreatePdfPromises.push(createPdfForApi(apiResult, apiVersionResult, allData, token));
      }
    }

    fetchAndCreatePdfPromises.push(
      fetchAndGeneratePdf(fetchIdentitiesAndGeneratePdf, token, generateAuthUserDetailsPDF, "./APIAnalysisOuput/Auth_User_Details_Report.pdf"),
      fetchAndGeneratePdf(fetchNonEmployeeRecordsAndGeneratePdf, token, generateNonEmployeeRecordsPDF, "./APIAnalysisOuput/NonEmployeeRecords_Report.pdf"),
      // Add other PDF generation tasks here
    );

    await Promise.all(fetchAndCreatePdfPromises);

  } catch (error) {
    _logger.error("Error: ", error);
    handleError(error);
  }
};

async function fetchAndGeneratePdf(fetchDataFn, token, generatePdfFn, outputPath) {
  const data = await fetchDataFn(token);
  await generatePdfFn(data, outputPath);
}


/**
 * Function to fetch data for a specific API.
 */
async function fetchApiData(api, token) {
  try {
    let page = 1;
    let totalPages = 1;
    let allData = [];

    while (page <= totalPages) {
      const apiConfig = getApiConfig(token, page, api);
      const response = await fetchDataWithRetry(apiConfig);

      _logger.debug(`Fetching page ${page} of ${api}...`);
      console.log(`Fetching page ${page} of ${api}...`);

      const data = response.data;
      allData = allData.concat(data);

      if (page === 1) {
        // please move the static values to constant
        const totalCountHeader = response.headers["x-total-count"];
        const totalCount = parseInt(totalCountHeader, constant.ten);

        if (!isNaN(totalCount)) {
          totalPages = Math.ceil(totalCount / constant.fifty);
        } else {
          _logger.error("Invalid total count received:", totalCountHeader);
          console.error("Invalid total count received:", totalCountHeader);
          break;
        }
      }

      page++;
    }

    return allData;
  } catch (error) {
    _logger.error("Error: ", error);
    throw error;
  }
}

/**
 * Function to create PDF for a specific API.
 */
async function createPdfForApi(apiResult, apiVersionResult, allData, token) {
  try {
    let outputPath = `./APIAnalysisOuput${apiResult}.pdf`;
    switch (apiResult) {
      case "/access-profiles":
        const results = await analyzeData(allData, token);
        createAccessProfilePdf(results, outputPath);
        break;
      case "/access-request-approvals/completed":
        const analysisResult = analyzeARAC(allData);
        createARCPdf(analysisResult, `./APIAnalysisOuput/access-request-approvals-completed.pdf`);
        break;
      case "/access-request-approvals/pending":
        const analysisResultARAP = analyseARAP(allData);
        createARAPPDF(analysisResultARAP, `./APIAnalysisOuput/access-request-approvals-pending.pdf`);
        break;
      case "/access-request-approvals/approval-summary":
        const analysisResultARAAS = getTotalARAASSummary(allData);
        createARAASPdf(analysisResultARAAS, `./APIAnalysisOuput/approval-summary.pdf`);
        break;
      case "/accounts":
        const galAnalysisResult = await analyseGAL(allData, token);
        createGALPdf(galAnalysisResult, outputPath);
        break;
      case "/campaigns":
        const glcAnalysisResult = analyzeGLC(allData);
        createGLCPdf(glcAnalysisResult, outputPath);
        break;
      case "/requestable-objects":
        const reqObjResult = analyzeReqObjResult(allData);
        createReqObjResultPdf(reqObjResult, outputPath);
        break;
      case "/roles":
        const rolesResults = analyzeRoles(allData);
        createRolesResultPdf(rolesResults, outputPath);
        break;
      case "/sources":
        if (config.api_type[0] == apiVersionResult) {
          const processedData = processData(allData);
          generatePDF(processedData, outputPath);
        } else {
          const resultData = processLBS(allData);
          generateSourcePDF(resultData, `./APIAnalysisOuput/beta-sources.pdf`);
        }
        break;
      case "/work-items":
        const analyzeGLWIResult = analyzeGLWI(allData);
        generateGLWIPDF(analyzeGLWIResult, outputPath);
        break;
      case "/sod-policies":
        const analyzeLSPResult = analyzeLSP(allData);
        generateLSPPDF(analyzeLSPResult, outputPath);
        break;
      case "/workflows":
        const analyzeGLWResult = analyzeGLW(allData);
        createGLWPDF(analyzeGLWResult, outputPath);
        break;
      case "/entitlements":
        const analyzeLBEResult = await analyzeLBE(allData, token);
        createLBEPDF(analyzeLBEResult, outputPath);
        break;
      case "/identities":
        const analyzeLBIResult = processLBI(allData);
        createLBIPDF(analyzeLBIResult, outputPath);
        break;
      default:
        console.log("Unsupported API:", api);
    }
  } catch (error) {
    _logger.error("Error: ", error);
    throw error;
  }
}

/**
 * Function to fetch data with retry logic.
 */
async function fetchDataWithRetry(apiConfig, retries = 0) {
  try {
    const response = await axios(apiConfig);
    return response;
  } catch (error) {
    if (retries < config.MAX_RETRIES && (error.code === 'ECONNABORTED' || error.response?.status >= 500)) {
      const delay = calculateDelay(retries);
      await delayAsync(delay);
      return fetchDataWithRetry(apiConfig, retries + 1);
    } else {
      _logger.error("Error: ", error);
      throw error;
    }
  }
}

/**
 * Function to calculate delay for retry.
 */
function calculateDelay(retries) {
  const baseDelay = config.INITIAL_DELAY * Math.pow(2, retries);
  const jitter = Math.random() * config.INITIAL_DELAY;
  return baseDelay + jitter;
}

/**
 * Function to delay execution asynchronously.
 */
function delayAsync(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Function to get the API configuration.
 */
function getApiConfig(token, page, api) {
  return {
    method: "get",
    url: `https://${config.tenant}.api.${config.domain}.com${api}?offset=${(page - 1) * 50}&limit=50&count=true`,
    headers: { Authorization: `Bearer ${token}` },
  };
}

/**
 * Function to handle errors.
 */
function handleError(error) {
  _logger.error("Error: ", error);
  console.error(error);
}

/**
 * Function to process API data and extract API result and version.
 */
function processApiData(api) {
  const apiResult = getApiResult(api);
  const apiVersionResult = getApiVersionResult(api);
  return { apiResult, apiVersionResult };
}

/**
 * Function to extract API result from URL.
 */
function getApiResult(api) {
  return api.substring(api.indexOf("/", 1));
}

/**
 * Function to extract API version result from URL.
 */
function getApiVersionResult(api) {
  const firstSlashInd = api.indexOf("/", 1);
  const secondSlashIndex = api.indexOf("/", firstSlashInd + 1);
  return api.substring(firstSlashInd, secondSlashIndex);
}

// Call the main function to start fetching data and creating PDFs
fetchDataAndCreatePdf();

module.exports = { fetchApiData };