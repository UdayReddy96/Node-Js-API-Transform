// Author: Uday Reddy

// Summary:
// This module provides functions for analyzing access-request-approvals/approval-summary (ARAAS) data and generating a PDF report based on the analysis results. The `getTotalARAASSummary` function calculates the total count of pending, approved, and rejected ARAAS entries. The `createARAASPdf` function utilizes the analysis results to generate a PDF report containing a summary of ARAAS data, including the counts of pending, approved, and rejected entries. These functions offer valuable insights into the approval status of access requests, aiding in monitoring and decision-making processes.

const PDFDocument = require("pdfkit");
const fs = require("fs"); 
const _logger = require("../Logger");
//Analyse ARAAS
const getTotalARAASSummary = (araas) => {
    let totalPending = 0;
    let totalApproved = 0;
    let totalRejected = 0;

    araas.forEach((araa) => {
        totalPending += araa.pending;
        totalApproved += araa.approved;
        totalRejected += araa.rejected;
    });

    return {
        "Total ARAAS.pending": totalPending,
        "Total ARAAS.approved": totalApproved,
        "Total ARAAS.rejected": totalRejected
    };
};

const createARAASPdf = (analysisResult, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Function to print ARAAS status
    const printARAASStatus = (title, status, count) => {
        doc
            .fontSize(12)
            .fillColor("#3366CC")
            .text(title, { underline: true })
            .fillColor("black")
            .moveDown(0.5);

        doc
            .font("Times-Roman")
            .fontSize(12)
            .text(`${status}: ${count}`)
            .moveDown(0.5);
    };

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    // Title
    doc.fontSize(20).text("access-request-approvals/approval-summary Analysis Report", { align: "center" }).moveDown();

    // Print Total access-request-approvals/approval-summary Summary
    printARAASStatus("Total access-request-approvals/approval-summary Summary", "Pending", analysisResult["Total ARAAS.pending"]);
    printARAASStatus("", "Approved", analysisResult["Total access-request-approvals/approval-summary.approved"]);
    printARAASStatus("", "Rejected", analysisResult["Total access-request-approvals/approval-summary.rejected"]);

    // End document and handle stream finish event
    doc.end();
    stream.on("finish", () =>
        console.log("access-request-approvals/approval-summary Analysis Report written to output.pdf")
    );
};


module.exports = { getTotalARAASSummary, createARAASPdf };