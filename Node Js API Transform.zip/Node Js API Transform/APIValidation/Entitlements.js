// Author: Uday Reddy

// Summary:
// This module provides functionalities to analyze List of Beta Entitlements (LBE) data and generate a PDF report based on the analysis. The `analyzeLBE` function calculates various metrics such as the total count of LBE, counts of privileged, cloud governed, and requestable LBEs, occurrences of different values for LBE source ID, and the top 5 occurrences of LBE owner ID. Additionally, it identifies orphan entitlements and attached entitlements by comparing LBE data with access profiles. The `createLBEPDF` function utilizes the analysis results to create a detailed PDF report containing summarized information on LBE profiles, including counts, lists of requestable LBEs, occurrences of source IDs and owner IDs, and orphan entitlements, providing valuable insights for stakeholders and decision-makers.

const PDFDocument = require('pdfkit');
const fs = require('fs');
const _logger = require("../Logger");

const analyzeLBE = async (lbeData, token) => {
    const result = {
        totalCount: 0,
        privileged: {
            trueCount: 0,
            falseCount: 0
        },
        cloudGoverned: {
            trueCount: 0,
            falseCount: 0
        },
        requestable: {
            trueCount: 0,
            falseCount: 0
        },
        sourceOccurrences: {},
        topOwnerOccurrences: {},
        requestableTrueList: [],
        orphanEntitlements: [],
        attachedEntitlements: [],
    };

    const { fetchApiData } = require("../app");
    const entitlements = lbeData.map(entitlement => ({ id: entitlement.id, name: entitlement.name }));
    //const entitlements = lbeData;
    const accessProfiles = await fetchApiData('/v3/access-profiles', token);

    for (const entitlement of entitlements) {
        let found = false;
        for (const profile of accessProfiles) {
            if (profile.entitlements && profile.entitlements.some(ent => ent.id === entitlement.id)) {
                found = true;
                result.attachedEntitlements.push(entitlement);
                break;
            }
        }
        if (!found) {
            result.orphanEntitlements.push(entitlement);
        }
    }

    if (Array.isArray(lbeData)) {
        result.totalCount = lbeData.length;

        lbeData.forEach(lbe => {
            // Total Count LBE.privileged == true, == false
            if (lbe.privileged === true) {
                result.privileged.trueCount++;
            } else if (lbe.privileged === false) {
                result.privileged.falseCount++;
            }

            // Total Count LBE.cloudGoverned == true, == false
            if (lbe.cloudGoverned === true) {
                result.cloudGoverned.trueCount++;
            } else if (lbe.cloudGoverned === false) {
                result.cloudGoverned.falseCount++;
            }

            // Total Count LBE.requestable == true, == false
            if (lbe.requestable === true) {
                result.requestable.trueCount++;
                result.requestableTrueList.push({ name: lbe.name, sourceName: lbe.source.name });
            } else if (lbe.requestable === false) {
                result.requestable.falseCount++;
            }

            // Total occurrences count of different values for LBE.source.id; print LBE.source.name and its count
            const sourceId = lbe.source && lbe.source.id;
            if (sourceId) {
                const sourceName = lbe.source.name || 'Unknown';
                const sourceKey = `${sourceName} (${sourceId})`;
                result.sourceOccurrences[sourceKey] = (result.sourceOccurrences[sourceKey] || 0) + 1;
            }


            // Top 5 occurrences count of different values for LBE.owner.id; print LBE.owner,name and its count
            const ownerId = lbe.owner && lbe.owner.id;
            if (ownerId) {
                const ownerName = lbe.owner.name || 'Unknown';
                result.topOwnerOccurrences[ownerId] = (result.topOwnerOccurrences[ownerId] || 0) + 1;
            }
        });

        // Sort the top owner occurrences by count and pick the top 5
        result.topOwnerOccurrences = Object.entries(result.topOwnerOccurrences)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .reduce((acc, [ownerId, count]) => {
                const ownerName = lbeData.find(lbe => lbe.owner && lbe.owner.id === ownerId)?.owner?.name || 'Unknown';
                acc[ownerId] = { name: ownerName, count };
                return acc;
            }, {});
    }

    return result;
}

const createLBEPDF = (analysisResult, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Function to print a list of profiles
    const printProfiles = (profiles) => {
        profiles.forEach((profile) => {
            doc
                .font("Times-Roman")
                .fontSize(12)
                .text(`  - ID: ${profile.id}, Name: ${profile.name}`)
                .moveDown(0.5); // Adjust line spacing
        });
    };

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    // Title
    doc.fontSize(20).text("List of Beta Entitlements Analysis Results", { align: "center" }).moveDown();

    // Total Count of LBE
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("Total Count of List of Beta Entitlements(LBE):", { underline: true })
        .fontSize(12)
        .fillColor("#666")
        .text(`${analysisResult.totalCount}`)
        .moveDown();

    // Total Count of LBE.privileged
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("Total Count of List of Beta Entitlements.privileged:", { underline: true })
        .fontSize(12)
        .fillColor("#666")
        .text(`True: ${analysisResult.privileged.trueCount}, False: ${analysisResult.privileged.falseCount}`)
        .moveDown();

    // Total Count of LBE.cloudGoverned
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("Total Count of List of Beta Entitlements.cloudGoverned:", { underline: true })
        .fontSize(12)
        .fillColor("#666")
        .text(`True: ${analysisResult.cloudGoverned.trueCount}, False: ${analysisResult.cloudGoverned.falseCount}`)
        .moveDown();

    // Total Count of LBE.requestable
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("Total Count of List of Beta Entitlements.requestable:", { underline: true })
        .fontSize(12)
        .fillColor("#666")
        .text(`True: ${analysisResult.requestable.trueCount}, False: ${analysisResult.requestable.falseCount}`)
        .moveDown();

    // List of LBEs with Requestable == true
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("List of Beta Entitlements with Requestable == true:", { underline: true });

    analysisResult.requestableTrueList.forEach(lbe => {
        doc
            .fontSize(12)
            .fillColor("#666")
            .text(`Name: ${lbe.name}, Source Name: ${lbe.sourceName}`);
    });

    // Occurrences of LBE.source.id
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("Occurrences of List of Beta Entitlements.source.id:", { underline: true });

    Object.entries(analysisResult.sourceOccurrences).forEach(([sourceKey, count]) => {
        doc
            .fontSize(12)
            .fillColor("#666")
            .text(`${sourceKey}: ${count}`);
    });

    // Top 5 occurrences of LBE.owner.id
    doc
        .fontSize(16)
        .fillColor("#333")
        .text("Top 5 occurrences of List of Beta Entitlements.owner.id:", { underline: true });

    Object.entries(analysisResult.topOwnerOccurrences).forEach(([ownerId, { name, count }]) => {
        doc
            .fontSize(12)
            .fillColor("#666")
            .text(`${name} (${ownerId}): ${count}`);
    });

    // Orphan Entitlements
    doc
        .fontSize(14)
        .fillColor("#3366CC")
        .font("Helvetica-Bold")
        .text("Orphan Entitlements:", { underline: true })
        .fillColor("black")
        .fontSize(12)
        .moveDown(0.5); // Adjust spacing

    analysisResult.orphanEntitlements.forEach(entitlement => {
        doc
            .font("Helvetica")
            .fontSize(12)
            .text(`Name: ${entitlement.name}, Id: ${entitlement.id}`);
    });

    doc.end();
};


module.exports = { analyzeLBE, createLBEPDF };
