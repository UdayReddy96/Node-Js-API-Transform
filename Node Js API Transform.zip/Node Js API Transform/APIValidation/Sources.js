// Author: Uday Reddy

// Summary:
// This module provides functions to process and generate PDF reports for data related to List of all sources in IdentityNow (LASI) and Load Balancer Sources (LBS). The `processData` function takes LASI data as input, calculates various statistics such as total count, counts occurrences of different values for LASI type, counts occurrences of LASI authoritative, LASI healthy, and returns the processed data. The `generatePDF` function generates a PDF report based on the processed LASI data, including total count, list of LASI names, counts of authoritative true/false, names with authoritative true, sources with empty accountCorrelationConfig, accountCorrelationRule, managerCorrelationMapping, managerCorrelationRule, passwordPolicies, type occurrences, and healthy true/false. The `processLBS` function takes LBS data as input, calculates statistics such as total count, enabled count, disabled count, and returns the pr

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

function processData(data) {
    // Total Count - LASI.Count
    const lasiCount = data.length;

    // Print all LASI.name
    const lasiNames = data.map(item => item.name);

    // Total Count LASI.authoritative == true, ==false
    const authoritativeTrueCount = data.filter(item => item.authoritative === true).length;
    const authoritativeFalseCount = data.filter(item => item.authoritative === false).length;

    // List all LASI.authoritative == true; print LASI.name
    const authoritativeTrueNames = data.filter(item => item.authoritative === true).map(item => item.name);

    // List all Source with LASL.accountCorrelationConfig is empty - print LASL.name
    const emptyAccountCorrelationConfig = data.filter(item => !item.accountCorrelationConfig).map(item => item.name);

    // List all Source with LASL.accountCorrelationRule is empty - print LASL.name
    const emptyAccountCorrelationRule = data.filter(item => !item.accountCorrelationRule).map(item => item.name);

    // List all Source with LASL.managerCorrelationMapping is empty - print LASL.name
    const emptyManagerCorrelationMapping = data.filter(item => !item.managerCorrelationMapping).map(item => item.name);

    // List all Source with LASL.managerCorrelationRule is empty - print LASL.name
    const emptyManagerCorrelationRule = data.filter(item => !item.managerCorrelationRule).map(item => item.name);

    // List all Source with LASL.passwordPolicies is empty - print LASL.name
    const emptyPasswordPolicies = data.filter(item => !item.passwordPolicies).map(item => item.name);

    // Total occurences count of different values for LASL.type
    const typeCounts = data.reduce((acc, curr) => {
        acc[curr.type] = (acc[curr.type] || 0) + 1;
        return acc;
    }, {});

    // Total Count LASI.healthy == true, ==false
    const healthyTrueCount = data.filter(item => item.healthy === true).length;
    const healthyFalseCount = data.filter(item => item.healthy === false).length;

    // List all LASI.healthy == false; print LASI.name
    const unhealthyNames = data.filter(item => item.healthy === false).map(item => item.name);

    // Return processed data
    return {
        lasiCount,
        lasiNames,
        authoritativeTrueCount,
        authoritativeFalseCount,
        authoritativeTrueNames,
        emptyAccountCorrelationConfig,
        emptyAccountCorrelationRule,
        emptyManagerCorrelationMapping,
        emptyManagerCorrelationRule,
        emptyPasswordPolicies,
        typeCounts,
        healthyTrueCount,
        healthyFalseCount,
        unhealthyNames
    };
}


function generatePDF(data, outputPath) {
    const doc = new PDFDocument();
    doc.pipe(fs.createWriteStream(outputPath));

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.fontSize(24).fillColor('#333333').text('Report', { align: 'center' });

    // Add spacing
    doc.moveDown();

    // Total Count - LASI.Count
    doc.fontSize(16).fillColor('#333333').text('Total Count of List of all sources in IdentityNow(LASI):', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`${data.lasiCount}`);

    // Add spacing
    doc.moveDown();

    // Print all LASI.name
    doc.fontSize(16).fillColor('#333333').text('List of all sources in IdentityNow(LASI) Names:', { underline: true });
    data.lasiNames.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // Total Count LASI.authoritative == true, ==false
    doc.fontSize(16).fillColor('#333333').text('Total Count of List of all sources in IdentityNow(LASI).authoritative:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`True: ${data.authoritativeTrueCount}, False: ${data.authoritativeFalseCount}`);

    // Add spacing
    doc.moveDown();

    // List all LASI.authoritative == true; print LASI.name
    doc.fontSize(16).fillColor('#333333').text('List of all sources in IdentityNow(LASI) Names with authoritative == true:', { underline: true });
    data.authoritativeTrueNames.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // List all Source with LASL.accountCorrelationConfig is empty
    doc.fontSize(16).fillColor('#333333').text('Sources with empty accountCorrelationConfig:', { underline: true });
    data.emptyAccountCorrelationConfig.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // List all Source with LASL.accountCorrelationRule is empty
    doc.fontSize(16).fillColor('#333333').text('Sources with empty accountCorrelationRule:', { underline: true });
    data.emptyAccountCorrelationRule.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // List all Source with LASL.managerCorrelationMapping is empty
    doc.fontSize(16).fillColor('#333333').text('Sources with empty managerCorrelationMapping:', { underline: true });
    data.emptyManagerCorrelationMapping.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // List all Source with LASL.managerCorrelationRule is empty
    doc.fontSize(16).fillColor('#333333').text('Sources with empty managerCorrelationRule:', { underline: true });
    data.emptyManagerCorrelationRule.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // List all Source with LASL.passwordPolicies is empty
    doc.fontSize(16).fillColor('#333333').text('Sources with empty passwordPolicies:', { underline: true });
    data.emptyPasswordPolicies.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    // Add spacing
    doc.moveDown();

    // Total occurences count of different values for LASL.type
    doc.fontSize(16).fillColor('#333333').text('Total occurrences count of different values for List of all sources in IdentityNow(LASI).type:', { underline: true });
    Object.entries(data.typeCounts).forEach(([type, count]) => doc.fontSize(12).fillColor('#666666').text(`${type}: ${count}`));

    // Add spacing
    doc.moveDown();

    // Total Count LASI.healthy == true, ==false
    doc.fontSize(16).fillColor('#333333').text('Total Count of List of all sources in IdentityNow(LASI).healthy:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`True: ${data.healthyTrueCount}, False: ${data.healthyFalseCount}`);

    // Add spacing
    doc.moveDown();

    // List all LASI.healthy == false
    doc.fontSize(16).fillColor('#333333').text('List of all sources in IdentityNow(LASI) Names with healthy == false:', { underline: true });
    data.unhealthyNames.forEach(name => doc.fontSize(12).fillColor('#666666').text(name));

    doc.end();
}

function processLBS(LBS) {
    const totalCount = LBS.length;
    const enabledCount = LBS.filter(item => item.enabled).length;
    const disabledCount = totalCount - enabledCount;

    const disabledItems = LBS.filter(item => !item.enabled).map(item => item.id);
    const failureItems = LBS.filter(item => item.failureCount > 0).map(item => item.id);

    return {
        totalCount,
        enabledCount,
        disabledCount,
        disabledItems,
        failureItems
    };
}


function generateSourcePDF(data, outputPath) {
    const doc = new PDFDocument();
    doc.pipe(fs.createWriteStream(outputPath));

    // Font
    doc.font('Helvetica-Bold');

    // Title
    doc.fontSize(20).text('LBS Data Processing', { align: 'center' }).moveDown();

    // Total Count,
    doc.fontSize(16).text(`Total Count: ${data.totalCount}`).moveDown();

    // // Enabled Count
    // doc.fontSize(16).text(`Enabled Count: ${data.enabledCount}`).moveDown();

    // // Disabled Count
    // doc.fontSize(16).text(`Disabled Count: ${data.disabledCount}`).moveDown();

    //// Disabled GLW IDs
    // doc.fontSize(16).text('Disabled GLW IDs:').moveDown();
    // data.disabledItems.forEach(item => doc.fontSize(14).text(item));

    //// GLW IDs with failure count greater than 0
    // doc.fontSize(16).text('GLW IDs with failure count greater than 0:').moveDown();
    // data.failureItems.forEach(item => doc.fontSize(14).text(item));

    doc.end();
}


module.exports = { processData, generatePDF, processLBS, generateSourcePDF };