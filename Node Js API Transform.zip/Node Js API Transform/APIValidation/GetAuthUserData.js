// Author: Uday Reddy

// Summary:
// This module contains functions to fetch user identities and generate a PDF report based on their details. The `fetchIdentitiesAndGeneratePdf` function fetches user identities and their details from the API using an authentication token. It then generates a PDF report containing details such as email address, display name, last password change date, last login timestamp, occurrences of capabilities, whether the user has ADMIN capabilities, and whether certain conditions are met regarding the last password change date and last login timestamp. The `generateAuthUserDetailsPDF` function generates the PDF report based on the fetched data. It includes a title, sections for users meeting specific conditions, and details such as email address, display name, and capabilities occurrences for each user in the sections.


const axios = require("axios");
const fs = require("fs");
const PDFDocument = require("pdfkit");
const config = require("../config");


async function fetchIdentitiesAndGeneratePdf(token) {
    try {
        let data = []; // Array to store key-value pairs
        const { fetchApiData } = require("../app");
        // Fetch data from the /beta/identities endpoint to get the IDs
        const identitiesResponse = await fetchApiData('/beta/identities', token);
        const identities = identitiesResponse;

        // Fetch data for each identity ID and populate data array
        for (const identity of identities) {
            const userDetails = await fetchAuthUserDetails(identity.id, token);
            if (userDetails.status && userDetails.status == 404) {
                data.push({
                    id_404: identity.id, Status_404: userDetails.status, Email: identity.emailAddress,
                })
            } else {
                for (const userDetail of userDetails) {
                    const userLastPasswordChangeDate = new Date(userDetail.lastPasswordChangeDate);
                    const userLastLoginTimestamp = new Date(userDetail.lastLoginTimestamp);
                    const capabilitiesOccurrences = countCapabilitiesOccurrences(userDetail.capabilities);
                    const isAdmin = checkAdminCapability(userDetail.capabilities);
                    const isPasswordChanged = isGreaterThan90Days(userDetail.lastPasswordChangeDate);
                    const isLoginTimestamp = isGreaterThan90Days(userDetail.lastLoginTimestamp);

                    data.push({
                        email: userDetail.email,
                        displayName: userDetail.displayName,
                        lastPasswordChangeDate: userLastPasswordChangeDate,
                        lastLoginTimestamp: userLastLoginTimestamp,
                        capabilitiesOccurrences,
                        isAdmin,
                        isPasswordChanged,
                        isLoginTimestamp
                    });
                }


            }

        }

        return data;

    } catch (error) {
        console.error("Error fetching data or generating PDF:", error);
    }
}

async function fetchAuthUserDetails(id, token) {
    try {
        const { fetchApiData } = require("../app");
        const response = await fetchApiData(`/v3/auth-users/${id}`, token);
        return response;
    } catch (error) {
        if (error.response.status == 404 && error.code == "ERR_BAD_REQUEST") {
            return { Id: id, status: error.response.status };
        } else {
            console.error(`Error fetching user details for ID ${id}:`, error);
            return null;
        }

    }
}

function countCapabilitiesOccurrences(capabilities) {
    const occurrences = {};
    // Check if capabilities is not null or undefined before iterating
    if (capabilities) {
        capabilities.forEach(capability => {
            occurrences[capability] = occurrences[capability] ? occurrences[capability] + 1 : 1;
        });
    }
    return occurrences;
}



function checkAdminCapability(capabilities) {
    // Check if capabilities is not null or undefined before using the some method
    if (capabilities) {
        return capabilities.some(capability => capability && capability.includes("ADMIN"));
    } else {
        return false; // or return default value based on your requirement
    }
}

async function generateAuthUserDetailsPDF(data, outputPath) {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.fontSize(20).text('Auth User Details Report', { align: 'center' }).moveDown();

    // Add spacing
    doc.moveDown();

    // Initialize arrays for each section
    const sections = [
        { heading: 'Users with lastPasswordChangeDate == null', key: 'lastPasswordChangeDate', condition: null },
        { heading: 'Users with lastPasswordChangeDate > 90 days', key: 'lastPasswordChangeDate', condition: user => user.isPasswordChanged },
        { heading: 'Users with lastLoginTimestamp == null', key: 'lastLoginTimestamp', condition: null },
        { heading: 'Users with lastLoginTimestamp > 90 days', key: 'lastLoginTimestamp', condition: user => user.isLoginTimestamp },
        { heading: 'Different occurrences of capabilities', key: 'capabilitiesOccurrences', condition: user => user.capabilitiesOccurrences },
        { heading: 'Users with ADMIN capabilities', key: 'isAdmin', condition: user => user.isAdmin },
        { heading: 'Emails with Status 404 Report', key: 'Status_404', condition: user => user.Status_404 === 404 }
    ];

    // Process each identity in the data and populate the sections
    for (const section of sections) {
        const sectionData = data.filter(user => section.condition ? section.condition(user) : user[section.key] === section.condition);
        if (sectionData.length > 0) {
            doc.text(section.heading, { align: 'left', underline: true }).moveDown();
            sectionData.forEach(user => {
                doc.fontSize(16).text(`Email: ${user.email}`, { align: 'left' });
                if (user.displayName) {
                    doc.fontSize(16).text(`Display Name: ${user.displayName}`, { align: 'left' });
                }
                if (section.key === 'capabilitiesOccurrences') {
                    Object.entries(user.capabilitiesOccurrences).forEach(([capability, count]) => {
                        doc.fontSize(14).text(`${capability}: ${count}`, { align: 'left' });
                    });
                }
                doc.moveDown();
            });
        }
    }

    doc.end();
}




function isGreaterThan90Days(date) {
    const currentDate = new Date();
    const diffInMilliseconds = currentDate - new Date(date);
    const diffInDays = diffInMilliseconds / (1000 * 3600 * 24);
    return diffInDays > 90;
}

module.exports = { fetchIdentitiesAndGeneratePdf, generateAuthUserDetailsPDF };