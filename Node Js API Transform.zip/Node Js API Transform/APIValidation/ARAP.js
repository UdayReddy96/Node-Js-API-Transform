// Author: Uday Reddy

// Summary:
// This module offers functions for analyzing Access Request Approval Pending (ARAP) profiles and generating a PDF report based on the analysis. The `analyseARAP` function calculates various metrics such as the total count of ARAP, the count of ARAP pending for more than 3 months, counts where ARAC requester equals ARAC reviewedBy, and analyzes violated policies. The `createARAPPDF` function utilizes the analysis results to create a detailed PDF report containing summarized information on ARAP profiles, including counts, lists of profiles pending for more than 3 months, counts where requester equals reviewedBy, and violated policies, providing insights for stakeholders and decision-makers.

const PDFDocument = require("pdfkit");
const fs = require("fs");
const moment = require("moment");

// Analyse ARAP
const analyseARAP = (arapProfiles) => {
    const analysisResult = {
        totalCount: arapProfiles.length,
        totalCountOlderThan3Months: 0,
        arapNamesPendingForMoreThan3Months: [],
        violatedPolicies: [],
        requesterEqualsReviewedByCount: 0,
        requesterEqualsReviewedByNames: [],
    };

    // Filter ARAP profiles pending for more than 3 months
    analysisResult.arapNamesPendingForMoreThan3Months = arapProfiles
        .filter((profile) => moment().diff(moment(profile.created), "months") >= 3)
        .map((profile) => profile.name);

    analysisResult.totalCountOlderThan3Months = analysisResult.arapNamesPendingForMoreThan3Months.length;

    // Count of ARAC where ARAC.requester == ARAC.reviewedBy
    analysisResult.requesterEqualsReviewedByCount = arapProfiles.filter(
        (arap) => arap.requester && arap.reviewedBy && arap.requester.id === arap.reviewedBy.id
    ).length;

    // List ARAP names where ARAC.requester == ARAC.reviewedBy
    analysisResult.requesterEqualsReviewedByNames = arapProfiles.filter(
        (arap) => arap.requester && arap.reviewedBy && arap.requester.id === arap.reviewedBy.id
    ).map(arap => arap.name);

    // Analyze violated policies
    arapProfiles.forEach((profile) => {
        if (profile.sodViolationContext && profile.sodViolationContext.violationCheckResult) {
            const violatedPolicies = profile.sodViolationContext.violationCheckResult.violatedPolicies;
            violatedPolicies.forEach((policy) => {
                analysisResult.violatedPolicies.push({
                    policy: policy.name,
                    requestedFor: profile.requestedFor.name,
                    requestedObject: profile.requestedObject.name,
                });
            });
        }
    });

    return analysisResult;
};

const createARAPPDF = (analysisResult, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Function to print a list of items
    const printList = (title, items) => {
        doc
            .fontSize(12)
            .fillColor("#3366CC")
            .text(title, { underline: true })
            .fillColor("black")
            .moveDown(0.5);

        Object.entries(items).forEach(([item, value]) => {
            if (typeof value === 'string') {
                const lines = value.split('\n'); // Split value into separate lines
                lines.forEach(line => {
                    doc
                        .font("Times-Roman")
                        .fontSize(12)
                        .text(`${item}: ${line}`) // Print each line separately
                        .moveDown(0.5);
                });
            } else {
                // If value is not a string, simply print it as is
                doc
                    .font("Times-Roman")
                    .fontSize(12)
                    .text(`${item}: ${value}`)
                    .moveDown(0.5);
            }
        });
    };

    
    // Title
    doc.fontSize(20).text("access-request-approvals/pending (ARAP) Analysis Report", { align: "center" }).moveDown();

    // Print Total Count of ARAP
    printList("Total Count of access-request-approvals/pending (ARAP)", {
        "Total Count": analysisResult.totalCount
    });

    // Print Total ARAP pending for more than 3 months
    printList("Total ARAP pending for more than 3 months", {
        "Total Count Older Than 3 Months": analysisResult.totalCountOlderThan3Months,
        "ARAP Names Pending for More Than 3 Months": analysisResult.arapNamesPendingForMoreThan3Months.join("\n")
    });

    printList("Count of access-request-approvals/pending (ARAP) where ARAC.requester == ARAC.reviewedBy", {
        "Count": analysisResult.requesterEqualsReviewedByCount
    });

    // Check if requesterEqualsReviewedByNames is defined before printing
    if (analysisResult.requesterEqualsReviewedByNames) {
        printList("List of access-request-approvals/pending (ARAP) names where ARAC.requester == ARAC.reviewedBy", {
            "Names": analysisResult.requesterEqualsReviewedByNames.join(', ')
        });
    }

    // Print Violated Policy
    printList("Violated Policy", {
        "Non-empty Count": analysisResult.violatedPolicies.length,
    });

    analysisResult.violatedPolicies.forEach((policy, index) => {
        doc
            .font("Times-Roman")
            .fontSize(12)
            .text(`Policy ${index + 1}: ${policy.policy}`)
            .text(`Requested For: ${policy.requestedFor}`)
            .text(`Requested Object: ${policy.requestedObject}`)
            .moveDown(0.5);
    });

    // End document and handle stream finish event
    doc.end();
    stream.on("finish", () =>
        console.log("access-request-approvals/pending (ARAP) Analysis Report written to output.pdf")
    );
};

module.exports = { analyseARAP, createARAPPDF };
