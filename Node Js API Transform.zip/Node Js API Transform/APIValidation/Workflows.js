// Author: Uday Reddy

// Summary:
// This module provides functions to analyze and generate PDF reports for data related to workflows (GLW). The `analyzeGLW` function takes GLW data as input, calculates various statistics such as total count, counts of enabled workflows (true/false), counts of workflows with failure count greater than zero, and returns the analysis result. The `createGLWPDF` function generates a PDF report based on the analysis result of GLW data, including total count, counts of enabled workflows, lists of workflows where enabled is false and failure count is greater than zero.

const PDFDocument = require('pdfkit');
const fs = require('fs');
const _logger = require("../Logger");

function analyzeGLW(glwData) {
    const result = {
        totalCount: 0,
        enabled: {
            trueCount: 0,
            falseCount: 0,
            falseIds: []
        },
        failureCount: {
            greaterThanZero: 0,
            ids: []
        }
    };

    if (Array.isArray(glwData)) {
        result.totalCount = glwData.length;

        glwData.forEach(glw => {
            // Total Count GLW.enabled == true, == false
            if (glw.enabled === true) {
                result.enabled.trueCount++;
            } else if (glw.enabled === false) {
                result.enabled.falseCount++;
                result.enabled.falseIds.push({ name: glw.name, id: glw.id });
            }

            // Total Count GLW.failureCount>0
            if (glw.failureCount > 0) {
                result.failureCount.greaterThanZero++;
                result.failureCount.ids.push({ name: glw.name, id: glw.id });
            }
        });
    }

    return result;
}

function createGLWPDF(glwAnalysisResult, outputPath) {
    const doc = new PDFDocument();
    doc.pipe(fs.createWriteStream(outputPath));

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.fontSize(24).fillColor('#333333').text('Workflows Analysis Report', { align: 'center' });

    // Add spacing
    doc.moveDown();

    // Total Count - GLW.count
    doc.fontSize(16).fillColor('#333333').text('Total Count of Workflows:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`${glwAnalysisResult.totalCount}`);

    // Add spacing
    doc.moveDown();

    // Total Count GLW.enabled == true, == false
    doc.fontSize(16).fillColor('#333333').text('Total Count of Workflows where enabled is true:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`${glwAnalysisResult.enabled.trueCount}`);

    doc.fontSize(16).fillColor('#333333').text('Total Count of Workflows where enabled is false:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`${glwAnalysisResult.enabled.falseCount}`);

    // Add spacing
    doc.moveDown();

    // List all GLW.enabled == false; print GLW.id and GLW.name
    if (glwAnalysisResult.enabled.falseIds.length > 0) {
        doc.fontSize(16).fillColor('#333333').text('List of Workflows where enabled is false:', { underline: true });
        // glwAnalysisResult.enabled.falseIds.forEach((id, index) => {
        //     doc.fontSize(12).fillColor('#666666').text(`${index + 1}. ID: ${id}`);
        // });

        Object.entries(glwAnalysisResult.enabled.falseIds).forEach(([id, { name }], index) => {
            doc.fontSize(12).fillColor('#666666').text(`${index + 1}. Name: ${name}, ID: ${id}`);
        });


    } else {
        doc.fontSize(16).fillColor('#333333').text('No Workflow found where enabled is false.', { underline: true });
    }

    // Add spacing
    doc.moveDown();

    // List all GLW.failureCount>0; print GLW.id and GLW.name
    if (glwAnalysisResult.failureCount.greaterThanZero > 0) {
        doc.fontSize(16).fillColor('#333333').text('List of Workflows where failureCount > 0:', { underline: true });
        glwAnalysisResult.failureCount.ids.forEach((id, index) => {
            doc.fontSize(12).fillColor('#666666').text(`${index + 1}. ID: ${id}`);
        });
    } else {
        doc.fontSize(16).fillColor('#333333').text('No Workflow found where failureCount > 0.', { underline: true });
    }

    doc.end();
}

module.exports = { analyzeGLW, createGLWPDF };
