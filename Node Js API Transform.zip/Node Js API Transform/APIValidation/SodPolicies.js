// Author: Uday Reddy

// Summary:
// This module provides functions to analyze and generate a PDF report for List of sod-policies (LSP) data. The `analyzeLSP` function takes an array of LSP data, counts various statistics such as total count, state occurrences, scheduled count, top owner reference occurrences, top violation owner assignment configuration occurrences, assignment rule occurrences, duplicate conflicting access criteria, and type occurrences, and returns the analysis result. The `generateLSPPDF` function generates a PDF report based on the provided analysis result, includ

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

function analyzeLSP(lspData) {
    const result = {
        totalCount: 0,
        topOwnerRefOccurrences: {},
        stateOccurrences: {},
        scheduledCount: 0,
        notScheduledCount: 0,
        topViolationOwnerAssignmentConfig: {},
        assignmentRuleOccurrences: {},
        duplicateConflictingAccessCriteria: {},
        typeOccurrences: {}
    };

    if (Array.isArray(lspData)) {
        result.totalCount = lspData.length;

        const ownerRefOccurrences = {};
        const violationOwnerAssignmentConfigOccurrences = {};
        const conflictingAccessCriteriaOccurrences = {}; // New addition

        lspData.forEach(lsp => {
            // Total occurrences count of different values for LSP.state
            const state = lsp.state;
            if (state) {
                result.stateOccurrences[state] = (result.stateOccurrences[state] || 0) + 1;
            }

            // Total count - LSP.scheduled == true, == false
            if (lsp.scheduled === true) {
                result.scheduledCount++;
            } else if (lsp.scheduled === false) {
                result.notScheduledCount++;
            }

            // Iterate every LSP, find LSP.ownerRef - Top 5 occurrences of LSP.ownerRef.id - print LSP.ownerRef.name and id
            const ownerRef = lsp.ownerRef;
            if (ownerRef) {
                const { id, name } = ownerRef;
                ownerRefOccurrences[id] = ownerRefOccurrences[id] ? ownerRefOccurrences[id] + 1 : 1;
                result.topOwnerRefOccurrences = Object.entries(ownerRefOccurrences)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 5)
                    .reduce((acc, [id, count]) => {
                        acc[id] = { name: lsp.ownerRef.name, count };
                        return acc;
                    }, {});
            }

            // Iterate every LSP, find LSP.violationOwnerAssignmentConfig.ownerRef - Top 5 occurrences of LSP.violationOwnerAssignmentConfig.ownerRef.id - print LSP.violationOwnerAssignmentConfig.ownerRef.name and id
            const violationOwnerAssignmentConfig = lsp.violationOwnerAssignmentConfig;
            if (violationOwnerAssignmentConfig && violationOwnerAssignmentConfig.ownerRef) {
                const { id, name } = violationOwnerAssignmentConfig.ownerRef;
                violationOwnerAssignmentConfigOccurrences[id] = violationOwnerAssignmentConfigOccurrences[id] ? violationOwnerAssignmentConfigOccurrences[id] + 1 : 1;
                result.topViolationOwnerAssignmentConfig = Object.entries(violationOwnerAssignmentConfigOccurrences)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 5)
                    .reduce((acc, [id, count]) => {
                        acc[id] = { name: violationOwnerAssignmentConfig.ownerRef.name, count };
                        return acc;
                    }, {});
            }

            // List count of different value occurrences for LSP.violationOwnerAssignmentConfig.assignmentRule values
            const assignmentRule = violationOwnerAssignmentConfig && violationOwnerAssignmentConfig.assignmentRule;
            result.assignmentRuleOccurrences[assignmentRule !== null ? assignmentRule : 'null'] = (result.assignmentRuleOccurrences[assignmentRule !== null ? assignmentRule : 'null'] || 0) + 1;

            // Duplicate combination of LSP.conflictingAccessCriteria.leftCriteria and rightCriteria
            const conflictingAccessCriteria = lsp.conflictingAccessCriteria;
            if (conflictingAccessCriteria && conflictingAccessCriteria.leftCriteria && conflictingAccessCriteria.rightCriteria) {
                const leftCriteriaList = conflictingAccessCriteria.leftCriteria.criteriaList.map(criteria => `${criteria.name}: ${criteria.id}`).sort().join(', ');
                const rightCriteriaList = conflictingAccessCriteria.rightCriteria.criteriaList.map(criteria => `${criteria.name}: ${criteria.id}`).sort().join(', ');

                const combination = `${leftCriteriaList} - ${rightCriteriaList}`;
                conflictingAccessCriteriaOccurrences[combination] = (conflictingAccessCriteriaOccurrences[combination] || { count: 0, lspList: [] }); // New addition
                conflictingAccessCriteriaOccurrences[combination].count++;
                conflictingAccessCriteriaOccurrences[combination].lspList.push({ id: lsp.id, name: lsp.name });
            }

            // Total occurrences count of different values for LSP.type
            const type = lsp.type;
            if (type) {
                result.typeOccurrences[type] = (result.typeOccurrences[type] || 0) + 1;
            }
        });

        // Filter out non-duplicate conflicting access criteria combinations
        Object.entries(conflictingAccessCriteriaOccurrences).forEach(([combination, { count, lspList }]) => {
            if (count > 1) {
                result.duplicateConflictingAccessCriteria[combination] = { count, lspList };
            }
        });
    }

    return result;
}

function generateLSPPDF(lspData, outputPath) {
    const analysisResult = lspData;

    const doc = new PDFDocument();
    doc.pipe(fs.createWriteStream(outputPath));

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.fontSize(24).fillColor('#333333').text('List of sod-policies(LSP) Analysis Report', { align: 'center' });

    // Add spacing
    doc.moveDown();

    // Total Count - LSP.Count
    doc.fontSize(16).fillColor('#333333').text('Total Count of List of sod-policies(LSP):', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`${analysisResult.totalCount}`);

    // Add spacing
    doc.moveDown();

    // Iterate every LSP, find LSP.ownerRef - Top 5 occurrences of LSP.ownerRef.id - print LSP.ownerRef.name and id
    doc.fontSize(16).fillColor('#333333').text('Top 5 occurrences of List of sod-policies(LSP).ownerRef:', { underline: true });
    Object.entries(analysisResult.topOwnerRefOccurrences).forEach(([id, { name, count }], index) => {
        doc.fontSize(12).fillColor('#666666').text(`${index + 1}. Name: ${name}, ID: ${id}, Count: ${count}`);
    });

    // Add spacing
    doc.moveDown();

    // Total occurrences count of different values for LSP.state
    doc.fontSize(16).fillColor('#333333').text('Total occurrences count of different values for List of sod-policies(LSP).state:', { underline: true });
    Object.entries(analysisResult.stateOccurrences).forEach(([state, count]) => {
        doc.fontSize(12).fillColor('#666666').text(`${state}: ${count}`);
    });

    // Add spacing
    doc.moveDown();

    // Total count - LSP.scheduled == true, == false
    doc.fontSize(16).fillColor('#333333').text('Total count of List of sod-policies(LSP).scheduled:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`True: ${analysisResult.scheduledCount}, False: ${analysisResult.notScheduledCount}`);

    // Add spacing
    doc.moveDown();

    // Iterate every LSP, find LSP.violationOwnerAssignmentConfig.ownerRef - Top 5 occurrences of LSP.violationOwnerAssignmentConfig.ownerRef.id - print LSP.violationOwnerAssignmentConfig.ownerRef.name and id
    doc.fontSize(16).fillColor('#333333').text('Top 5 occurrences of List of sod-policies(LSP).violationOwnerAssignmentConfig.ownerRef:', { underline: true });
    Object.entries(analysisResult.topViolationOwnerAssignmentConfig).forEach(([id, { name, count }], index) => {
        doc.fontSize(12).fillColor('#666666').text(`${index + 1}. Name: ${name}, ID: ${id}, Count: ${count}`);
    });

    // Add spacing
    doc.moveDown();

    // List count of different value occurrences for LSP.violationOwnerAssignmentConfig.assignmentRule values
    doc.fontSize(16).fillColor('#333333').text('List count of different value occurrences for List of sod-policies(LSP).violationOwnerAssignmentConfig.assignmentRule:', { underline: true });
    Object.entries(analysisResult.assignmentRuleOccurrences).forEach(([rule, count]) => {
        doc.fontSize(12).fillColor('#666666').text(`${rule}: ${count}`);
    });

    // Add spacing
    doc.moveDown();

    // Duplicate combination of LSP.conflictingAccessCriteria.leftCriteria and rightCriteria
    // Duplicate combination of LSP.conflictingAccessCriteria.leftCriteria and rightCriteria
    doc.fontSize(16).fillColor('#333333').text('Duplicate combination of List of sod-policies(LSP).conflictingAccessCriteria.leftCriteria and rightCriteria:', { underline: true });
    Object.entries(analysisResult.duplicateConflictingAccessCriteria).forEach(([combination, { count, lspList }]) => {
        doc.fontSize(12).fillColor('#666666').text(`${combination}: Count: ${count}`);
        doc.fontSize(12).fillColor('#666666').text(`Associated List of sod-policies:`);
        lspList.forEach(lsp => {
            doc.fontSize(10).fillColor('#666666').text(`sod-policy Name: ${lsp.name}, Id: ${lsp.id}`);
        });
        doc.moveDown();
    });


    // Add spacing
    doc.moveDown();

    // Total occurrences count of different values for LSP.type
    doc.fontSize(16).fillColor('#333333').text('Total occurrences count of different values for List of sod-policies(LSP).type:', { underline: true });
    Object.entries(analysisResult.typeOccurrences).forEach(([type, count]) => {
        doc.fontSize(12).fillColor('#666666').text(`${type}: ${count}`);
    });

    doc.end();
}


module.exports = { analyzeLSP, generateLSPPDF };
