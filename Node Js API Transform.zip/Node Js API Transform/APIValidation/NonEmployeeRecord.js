// Author: Uday Reddy

// Summary:
// This module provides functions to fetch non-employee records data, process it, and generate a PDF report. The `fetchNonEmployeeRecordsAndGeneratePdf` function fetches non-employee records data from an API endpoint, counts the occurrences of source IDs, retrieves source names for each source ID, constructs a data array with source names and occurrence counts, and returns the total count and data array. The `generateNonEmployeeRecordsPDF` function generates a PDF report based on the provided data, including a title, total count of records, and details of each record's source ID, source name, and count.

const axios = require("axios");
const fs = require("fs");
const PDFDocument = require("pdfkit");
const config = require("../config");


async function fetchNonEmployeeRecordsAndGeneratePdf(token) {
    try {
        let data = []; // Array to store key-value pairs

        const { fetchApiData } = require("../app");
        // Fetch non-employee records
        const response = await fetchApiData('/v3/non-employee-records', token);
        const nonEmployeeRecords = response;

        // Get total count of non-employee records
        const totalCount = nonEmployeeRecords.length;

        // Count occurrences of source IDs
        const sourceIdOccurrences = countSourceIdOccurrences(nonEmployeeRecords);

        // Get source names for each source ID
        const sourceNames = await fetchSourceNames(sourceIdOccurrences, token);

        // Construct data array with source names and occurrence counts
        data = constructDataArray(sourceIdOccurrences, sourceNames);

        return {
            totalCount,
            data
        };

    } catch (error) {
        console.error("Error fetching data or generating PDF:", error);
    }
}

function countSourceIdOccurrences(nonEmployeeRecords) {
    const occurrences = {};
    if (nonEmployeeRecords && nonEmployeeRecords.length > 0) {
        nonEmployeeRecords.forEach(record => {
            const sourceId = record.sourceId; // Assuming 'sourceId' is the correct property name
            if (sourceId) {
                occurrences[sourceId] = occurrences[sourceId] ? occurrences[sourceId] + 1 : 1;
            }
        });
    }
    return occurrences;
}



async function fetchSourceNames(sourceIdOccurrences, token) {
    const sourceNames = {};
    if (sourceIdOccurrences && Object.keys(sourceIdOccurrences).length > 0) {
        const sourceIds = Object.keys(sourceIdOccurrences);
        const { fetchApiData } = require("../app");
        for (const sourceId of sourceIds) {
            try {
                const response = await fetchApiData(`/beta/sources/${sourceId}`, token);
                sourceNames[sourceId] = response[0].name;
            } catch (error) {
                console.error(`Error fetching source name for source ID ${sourceId}:`, error);
                sourceNames[sourceId] = null;
            }
        }
    }
    return sourceNames;
}

function constructDataArray(sourceIdOccurrences, sourceNames) {
    const data = [];
    if (sourceIdOccurrences && sourceNames) {
        Object.entries(sourceIdOccurrences).forEach(([sourceId, count]) => {
            const sourceName = sourceNames[sourceId] || "Unknown Source";
            data.push({
                sourceId,
                sourceName,
                count
            });
        });
    }
    return data;
}



async function generateNonEmployeeRecordsPDF(data, outputPath) {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.fontSize(20).text('Non-Employee Records Report', { align: 'center' }).moveDown();

    // Total Count
    doc.fontSize(16).text(`Total Count: ${data.totalCount}`, { align: 'left' }).moveDown();

    // Source ID Occurrences
    doc.fontSize(16).text("Source ID Occurrences:", { align: 'left' }).moveDown();
    if (data && data.data) {
        data.data.forEach(record => {
            doc.fontSize(14).text(`Source Name: ${record.sourceName}`, { align: 'left' });
            doc.fontSize(14).text(`Source ID: ${record.sourceId}`, { align: 'left' });
            doc.fontSize(14).text(`Count: ${record.count}`, { align: 'left' });
            doc.fontSize(14).text("----------------------------------", { align: 'left' }).moveDown();
        });
    }

    doc.end();
}

module.exports = { fetchNonEmployeeRecordsAndGeneratePdf, generateNonEmployeeRecordsPDF };