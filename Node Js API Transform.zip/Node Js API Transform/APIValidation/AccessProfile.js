// Author: Uday Reddy

// Summary:
// This module contains functions authored by Uday Reddy for analyzing access profile data and generating PDF reports based on the analysis results. The `analyzeData` function processes the data to compute various statistics such as duplicate profiles, requestable/non-requestable counts, entitlements summaries, approval schemes, etc. The `createAccessProfilePdf` function utilizes the analysis results to generate a comprehensive PDF report, including sections for AP segregation by owner and source, duplicate entitlements, entitlements summary, active/inactive APs, approval schemes, revocation request config, and orphan access profiles. These functions provide valuable insights into access profile data for effective management and decision-making.

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

// Function to analyze data
const analyzeData = async (data, token) => {
    let results = {
        duplicateProfiles: {},
        requestableCount: 0,
        nonRequestableCount: 0,
        listNonRequestable: [],
        listRequestable: [],
        singleEntitlementCount: 0,
        countBlankOrNoEntry: 0,
        countCommentsRequired: 0,
        countMultipleEntries: 0,
        countGovGroup: 0,
        countIdentity: 0,
        countSingleEntitlement: 0,
        countMultipleEntitlements: 0,
        countZeroEntitlements: 0,
        countNoApproval: 0,
        countOneApproval: 0,
        countTwoOrMoreApproval: 0,
        listNoApproval: [],
        listOneApproval: [],
        listTwoOrMoreApproval: [],
        countNoRevocation: 0,
        countOneRevocation: 0,
        countTwoOrMoreRevocation: 0,
        listNoRevocation: [],
        listOneRevocation: [],
        listTwoOrMoreRevocation: [],
        ActiveAPCount: 0,
        InActiveAPCount: 0,
        listActiveAP: [],
        zeroEntitlementsProfileList: [],
        listInActiveAP: [],
        countByOwnerType: {},
        topOwners: [],
        countBySource: {},
        totalAPCount: 0,
        attachedAPs: [],
        orphanAps: [],
    };


    const { fetchApiData } = require("../app");
    const accessProfiles = data.map(Ap => ({ id: Ap.id, name: Ap.name }));
    //const entitlements = lbeData;
    const roles = await fetchApiData('/v3/roles', token);

    for (const accessProfile of accessProfiles) {
        let found = false;
        for (const role of roles) {
            if (role.accessProfiles && role.accessProfiles.some(ap => ap.id === accessProfile.id)) {
                found = true;
                results.attachedAPs.push(accessProfile);
                break;
            }
        }
        if (!found) {
            results.orphanAps.push(accessProfile);
        }
    }

    const entitlementsMap = {};
    const ownerCountMap = {};

    results.totalAPCount = data.length;
    data.forEach((profile) => {
        const {
            entitlements,
            requestable,
            accessRequestConfig,
            revocationRequestConfig,
            enabled,
            source,
            owner,
        } = profile;

        const entitlementsKey = entitlements
            .map((e) => `${e.id}:${e.name}`) // Use both id and name for the key
            .sort()
            .join(",");

        if (entitlementsMap[entitlementsKey]) {
            results.duplicateProfiles[entitlementsKey] =
                results.duplicateProfiles[entitlementsKey] || [];
            const existingProfile = entitlementsMap[entitlementsKey];
            if (existingProfile) {
                results.duplicateProfiles[entitlementsKey].push({
                    id: existingProfile.profileId,
                    name: existingProfile.profileName,
                });
                delete entitlementsMap[entitlementsKey];
            }
            results.duplicateProfiles[entitlementsKey].push({
                id: profile.id,
                name: profile.name,
            });
        } else {
            entitlementsMap[entitlementsKey] = {
                profileName: profile.name,
                profileId: profile.id,
            };
        }

        if (owner && owner.type) {
            results.countByOwnerType[owner.type] =
                (results.countByOwnerType[owner.type] || 0) + 1;
        }

        const ownerId = owner?.id || "Unknown";
        ownerCountMap[ownerId] = (ownerCountMap[ownerId] || 0) + 1;

        const sourceName = source?.name || "Unknown";
        results.countBySource[sourceName] =
            (results.countBySource[sourceName] || 0) + 1;

        if (enabled) {
            results.ActiveAPCount++;
            results.listActiveAP.push({ name: profile.name, id: profile.id });
        } else {
            results.InActiveAPCount++;
            results.listInActiveAP.push({ name: profile.name, id: profile.id });
        }

        // results.requestableCount += requestable ? 1 : 0;
        if (requestable) {
            results.requestableCount++;
            results.listRequestable.push({ name: profile.name, id: profile.id });
        } else {
            results.nonRequestableCount++;
            results.listNonRequestable.push({ name: profile.name, id: profile.id });
        }
        // results.nonRequestableCount += requestable ? 0 : 1;
        results.singleEntitlementCount += entitlements?.length === 1 ? 1 : 0;
        //results.countZeroEntitlements += entitlements?.length === 0 ? 1 : 0;
        if (entitlements?.length === 0) {
            results.countZeroEntitlements++;
            results.zeroEntitlementsProfileList.push({ name: profile.name, id: profile.id });
        }

        results.countMultipleEntitlements += entitlements?.length > 1 ? 1 : 0;

        results.countBlankOrNoEntry +=
            !accessRequestConfig || Object.keys(accessRequestConfig).length === 0 ? 1 : 0;
        results.countCommentsRequired += accessRequestConfig?.commentsRequired ? 1 : 0;
        results.countMultipleEntries +=
            (accessRequestConfig?.approvalSchemes?.length || 0) > 1 ? 1 : 0;

        const numApprovals = accessRequestConfig?.approvalSchemes?.length || 0;
        results.countNoApproval += numApprovals === 0 ? 1 : 0;
        results.countOneApproval += numApprovals === 1 ? 1 : 0;
        results.countTwoOrMoreApproval += numApprovals > 1 ? 1 : 0;

        if (numApprovals === 0)
            results.listNoApproval.push({ name: profile.name, id: profile.id });
        else if (numApprovals === 1)
            results.listOneApproval.push({ name: profile.name, id: profile.id });
        else
            results.listTwoOrMoreApproval.push({
                name: profile.name,
                id: profile.id,
            });

        const numRevApprovals = revocationRequestConfig?.approvalSchemes?.length || 0;
        results.countNoRevocation += numRevApprovals === 0 ? 1 : 0;
        results.countOneRevocation += numRevApprovals === 1 ? 1 : 0;
        results.countTwoOrMoreRevocation += numRevApprovals > 1 ? 1 : 0;

        if (numRevApprovals === 0)
            results.listNoRevocation.push({ name: profile.name, id: profile.id });
        else if (numRevApprovals === 1)
            results.listOneRevocation.push({ name: profile.name, id: profile.id });
        else
            results.listTwoOrMoreRevocation.push({
                name: profile.name,
                id: profile.id,
            });
    });

    const ownerCountArray = Object.entries(ownerCountMap).map(
        ([ownerId, count]) => ({
            ownerId,
            count,
        })
    );

    ownerCountArray.sort((a, b) => b.count - a.count);
    const topOwners = ownerCountArray.slice(0, 5);

    const topOwnerNames = topOwners.map((entry) => {
        const { ownerId } = entry;
        const matchingProfile = data.find(
            (profile) => profile.owner && profile.owner.id === ownerId
        );
        return matchingProfile ? matchingProfile.owner.name : "Unknown";
    });

    results.topOwners = topOwnerNames;

    // Sort countBySource object by count in descending order
    results.countBySource = Object.fromEntries(
        Object.entries(results.countBySource).sort(([, a], [, b]) => b - a)
    );

    return results;
};

// Function to create PDF
const createAccessProfilePdf = (results, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Function to print a list of profiles
    const printProfiles = (profiles) => {
        profiles.forEach((profile) => {
            doc
                .font("Times-Roman")
                .fontSize(12)
                .text(`  - ID: ${profile.id}, Name: ${profile.name}`)
                .moveDown(0.5); // Adjust line spacing
        });
    };

    // Title
    doc.fontSize(20).text("Analysis Results", { align: "center" }).moveDown();

    doc.text(`Total count of Access profiles: ${results.totalAPCount}`)

    // Print AP Segregation by Owner
    doc
        .fillColor("#3366CC")
        .text("AP Segregation by Owner:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    // Classify count of different owner types
    Object.entries(results.countByOwnerType).forEach(([ownerType, count]) => {
        doc
            .text(`Number of Access Profiles with owner type "${ownerType}": ${count}`)
            .moveDown(0.5);
    });

    // List the top 5 owners with most entries along with their count
    doc
        .fillColor("#3366CC")
        .text("Top 5 Owners with Most Entries:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    // Retrieve top 5 owners
    const ownerCountArray = Object.entries(results.countByOwnerType).map(
        ([ownerType, count]) => ({ ownerType, count })
    );

    ownerCountArray.sort((a, b) => b.count - a.count);

    ownerCountArray.slice(0, 5).forEach(({ ownerType, count }, index) => {
        doc.text(`Owner ${index + 1}: ${ownerType}, Count: ${count}`).moveDown(0.5);
    });

    // Print AP Segregation by Source
    doc
        .fillColor("#3366CC")
        .text("Access Profile Segregation by Source:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    Object.entries(results.countBySource).forEach(([sourceName, count]) => {
        doc
            .text(`Number of APs with source "${sourceName}": ${count}`)
            .moveDown(0.5);
    });

    // Add spacing
    doc.moveDown();

    // Print Access Profiles with Duplicate Entitlements
    doc
        .fontSize(16)
        .fillColor("#3366CC")
        .text("Access Profiles with Duplicate Entitlements:", { underline: true })
        .fillColor("black")
        .fontSize(12)
        .moveDown(0.5); // Adjust spacing

    Object.entries(results.duplicateProfiles).forEach(([entitlements, profiles], index) => {
        doc
            .font("Helvetica-Bold")
            .fillColor("#990000")
            .text(`Group ${index + 1} (Duplicate Entitlements ID and Name: ${entitlements}):`)
            .fillColor("black");

        // Iterate through all access profiles to find profiles with the same entitlements combination
        printProfiles(profiles);
    });

    // Print Entitlements Summary
    doc
        .fillColor("#3366CC")
        .text("Entitlements Summary:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    doc
        .text(`Number of Access Profiles with single entitlement: ${results.singleEntitlementCount}`)
        .text(`Number of Access Profiles with multiple entitlements: ${results.countMultipleEntitlements}`)
        .text(`Number of Access Profiles with zero entitlements: ${results.countZeroEntitlements}`)
        .moveDown(0.5);
    doc.text(`List of Access Profiles with zero entitlements: `)
    printProfiles(results.zeroEntitlementsProfileList);
    doc.moveDown(0.5);
    // Print Analysis Summary
    doc
        .fillColor("#3366CC")
        .text("Analysis Summary:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    doc
        .text(`Number of Access Profiles with no entry or blank accessRequestConfig: ${results.countBlankOrNoEntry}`)
        .text(`Number of Access Profiles where CommentsRequired is true: ${results.countCommentsRequired}`)
        .text(`Number of Access Profiles with multiple approvalSchemes entries: ${results.countMultipleEntries}`)
        .text(`Number of access profiles mapped as requestable: ${results.requestableCount}`)
        .text(`List of access profiles mapped as requestable:`)
    printProfiles(results.listRequestable);
    doc.text(`Number of access profiles mapped as requestable as false: ${results.nonRequestableCount}`)
    doc.text(`List of access profiles mapped as requestable as false:`)
    printProfiles(results.listNonRequestable);

    doc.moveDown(0.5);

    // Print Active and InActive AP's:
    doc
        .fillColor("#3366CC")
        .text("Active and InActive Access Profile Summary:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    doc
        .text(`Number of Active Access Profiles : ${results.ActiveAPCount}`)
        .fillColor("#990000")
        .text("List of Active Access Profiles")
        .fillColor("black");

    printProfiles(results.listActiveAP);

    doc
        .text(`Number of InActiveAPs : ${results.InActiveAPCount}`)
        .fillColor("#990000")
        .text("List of InActive Access Profiles")
        .fillColor("black");

    printProfiles(results.listInActiveAP);

    // Print Approval Schemes Summary
    doc
        .fillColor("#3366CC")
        .text("Approval Schemes Summary:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    doc
        .text(`Number of Access Profiles with no approval schemes: ${results.countNoApproval}`)
        .fillColor("#990000")
        .text("List of Access Profiles with no approval schemes:")
        .fillColor("black");

    printProfiles(results.listNoApproval);

    doc
        .text(`Number of Access Profiles with one approval scheme: ${results.countOneApproval}`)
        .fillColor("#990000")
        .text("List of Access Profiles with one approval scheme:")
        .fillColor("black");

    printProfiles(results.listOneApproval);

    doc
        .text(`Number of Access Profiles with two or more approval schemes: ${results.countTwoOrMoreApproval}`)
        .fillColor("#990000")
        .text("List of Access Profiles with two or more approval schemes:")
        .fillColor("black");

    printProfiles(results.listTwoOrMoreApproval);

    // Print Revocation Request Config Summary
    doc
        .fillColor("#3366CC")
        .text("Revocation Request Config Summary:", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    doc
        .text(`Number of Access Profiles with no revocation approval schemes: ${results.countNoRevocation}`)
        .fillColor("#990000")
        .text("List of Access Profiles with no revocation approval schemes:")
        .fillColor("black");

    printProfiles(results.listNoRevocation);

    doc
        .text(`Number of Access Profiles with one revocation approval scheme: ${results.countOneRevocation}`)
        .fillColor("#990000")
        .text("List of Access Profiles with one revocation approval scheme:")
        .fillColor("black");

    printProfiles(results.listOneRevocation);

    doc
        .text(`Number of Access Profiles with two or more revocation approval schemes: ${results.countTwoOrMoreRevocation}`)
        .fillColor("#990000")
        .text("List of Access Profiles with two or more revocation approval schemes:")
        .fillColor("black");

    printProfiles(results.listTwoOrMoreRevocation);

    // // Orphan Entitlements
    // doc.fontSize(14).fillColor("#3366CC").font("Helvetica-Bold").text("Orphan Entitlements:");
    // results.orphanAps.forEach(Ap => {
    //     doc.text(`Name: ${Ap.name}, Id: ${Ap.id}`);
    // });


    // Print orphan Access Profiles
    doc
        .fontSize(14)
        .fillColor("#3366CC")
        .font("Helvetica-Bold")
        .text("Orphan Access profiles:", { underline: true })
        .fillColor("black")
        .font("Helvetica")
        .moveDown(0.5); // Adjust spacing

    printProfiles(results.orphanAps);

    // End document and handle stream finish event
    doc.end();
    stream.on("finish", () => {
        console.log(`Analysis results written to ${outputPath}`);
        _logger.debug(`Analysis results written to ${outputPath}`);
    });
};

module.exports = { analyzeData, createAccessProfilePdf };
