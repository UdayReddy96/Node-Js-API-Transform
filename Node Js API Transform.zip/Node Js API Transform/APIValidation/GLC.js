// Author: Uday Reddy

// Summary:
// This module contains functions to analyze and generate a PDF report for campaign data. The `analyzeGLC` function analyzes the provided campaign data, categorizing campaigns by type and status, counting the occurrences of email notification enabled and auto revoke allowed flags, and identifying uncorrelated campaigns. The `createGLCPdf` function generates a PDF report based on the analysis result, including a title, summary, categorization of campaign types and statuses, counts of email notification enabled and auto revoke allowed campaigns, and details of uncorrelated campaigns if present.


const PDFDocument = require("pdfkit");
const fs = require("fs");

const analyzeGLC = (glcData) => {
    let totalGLC = 0;
    const glcTypeCounts = {};
    const glcStatusCounts = {};
    let emailNotificationEnabledTrueCount = 0;
    let emailNotificationEnabledFalseCount = 0;
    let autoRevokeAllowedTrueCount = 0;
    let autoRevokeAllowedFalseCount = 0;

    const uncorrelatedGLCNames = [];

    glcData.forEach(glc => {
        totalGLC++;

        // Count GLC types
        glcTypeCounts[glc.type] = (glcTypeCounts[glc.type] || 0) + 1;

        // Count GLC statuses
        glcStatusCounts[glc.status] = (glcStatusCounts[glc.status] || 0) + 1;

        // Count emailNotificationEnabled
        if (glc.emailNotificationEnabled === true) {
            emailNotificationEnabledTrueCount++;
        } else {
            emailNotificationEnabledFalseCount++;
        }

        // Count autoRevokeAllowed
        if (glc.autoRevokeAllowed === true) {
            autoRevokeAllowedTrueCount++;
        } else {
            autoRevokeAllowedFalseCount++;
        }

        if (glc.correlatedStatus !== 'CORRELATED') {
            uncorrelatedGLCNames.push({ name: glc.name, description: glc.description });
        }
    });

    const analysisResult = {
        totalGLC,
        glcTypeCounts,
        glcStatusCounts,
        emailNotificationEnabledTrueCount,
        emailNotificationEnabledFalseCount,
        autoRevokeAllowedTrueCount,
        autoRevokeAllowedFalseCount,
        uncorrelatedGLCNames
    };

    return analysisResult;
};

const createGLCPdf = (analysisResult, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);

    doc.pipe(stream);

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.text('Campaigns Analysis Report', { align: 'center', underline: true });

    // Summary
    doc.text('Summary:', { underline: true });
    doc.text(`Total campaigns: ${analysisResult.totalGLC}`);
    doc.text('');

    // GLC Type Categorization
    doc.text('Campaigns Type Categorization:', { underline: true });
    for (const type in analysisResult.glcTypeCounts) {
        doc.text(`${type}: ${analysisResult.glcTypeCounts[type]}`);
    }
    doc.text('');

    // GLC Status Categorization
    doc.text('Campaigns Status Categorization:', { underline: true });
    for (const status in analysisResult.glcStatusCounts) {
        doc.text(`${status}: ${analysisResult.glcStatusCounts[status]}`);
    }
    doc.text('');

    // Count of emailNotificationEnabled
    doc.text(`Count of campaigns with emailNotificationEnabled == true: ${analysisResult.emailNotificationEnabledTrueCount}`);
    doc.text(`Count of campaigns with emailNotificationEnabled == false: ${analysisResult.emailNotificationEnabledFalseCount}`);
    doc.text('');

    // Count of autoRevokeAllowed
    doc.text(`Count of campaigns with autoRevokeAllowed == true: ${analysisResult.autoRevokeAllowedTrueCount}`);
    doc.text(`Count of campaigns with autoRevokeAllowed == false: ${analysisResult.autoRevokeAllowedFalseCount}`);
    doc.text('');

    // Details of Uncorrelated GLC

    if (analysisResult.uncorrelatedGLCNames.length != 0) {
        doc.text('Details of Uncorrelated campaigns:', { underline: true });
        analysisResult.uncorrelatedGLCNames.forEach(glc => {
            doc.text(`Name: ${glc.name}, Description: ${glc.description}`);
        });
    }


    doc.end();

    console.log(`PDF created successfully at ${outputPath}`);
};

module.exports = { analyzeGLC, createGLCPdf };
