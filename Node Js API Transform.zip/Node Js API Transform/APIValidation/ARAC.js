// Author: Uday Reddy

// Summary:
// This module provides functions for analyzing Access Request Approval Chains (ARAC) data and generating a PDF report based on the analysis results. The `analyzeARAC` function calculates various metrics such as the total count of ARAC, total count of different request types, top occurrences of ARAC requesters, requestedFor, reviewedBy, requestedObject, counts where requester equals requestedFor or reviewedBy, categorizes total counts of different values for ARAC state, identifies duplicate combinations of requestedFor and requestedObject, and detects violated policies. The `createARCPdf` function utilizes the analysis results to

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

function analyzeARAC(aracArray) {
    // Total count of ARAC
    const totalCount = aracArray.length;

    // Total count of different request types
    const requestTypes = {};
    aracArray.forEach((arac) => {
        requestTypes[arac.requestType] = (requestTypes[arac.requestType] || 0) + 1;
    });

    // Top 5 occurrence of most ARAC.requester
    const topRequesters = {};
    aracArray.forEach((arac) => {
        const requester = arac.requester;
        const key = `${requester.name} (${requester.id})`;
        topRequesters[key] = (topRequesters[key] || 0) + 1;
    });

    // Top 5 occurrence of most ARAC.requestedFor
    const topRequestedFor = {};
    aracArray.forEach((arac) => {
        const requestedFor = arac.requestedFor;
        const key = `${requestedFor.name} (${requestedFor.id})`;
        topRequestedFor[key] = (topRequestedFor[key] || 0) + 1;
    });

    // Top 5 occurrence of most ARAC.reviewedBy
    const topReviewedBy = {};
    aracArray.forEach((arac) => {
        const reviewedBy = arac.reviewedBy;
        const key = `${reviewedBy.name} (${reviewedBy.id})`;
        topReviewedBy[key] = (topReviewedBy[key] || 0) + 1;
    });

    // Top 5 occurrence of most ARAC.requestedObject
    const topRequestedObject = {};
    aracArray.forEach((arac) => {
        const requestedObject = arac.requestedObject;
        const key = `${requestedObject.name} (${requestedObject.id})`;
        topRequestedObject[key] = (topRequestedObject[key] || 0) + 1;
    });

    // Count of ARAC where ARAC.requester == ARAC.requestedFor
    const requesterEqualsRequestedForCount = aracArray.filter(
        (arac) => arac.requester.id === arac.requestedFor.id
    ).length;

    // Count of ARAC where ARAC.requester == ARAC.reviewedBy
    const requesterEqualsReviewedByCount = aracArray.filter(
        (arac) => arac.requester.id === arac.reviewedBy.id
    ).length;


    // List ARAC names where ARAC.requester == ARAC.reviewedBy
    const requesterEqualsReviewedByNames = aracArray.filter(
        (arac) => arac.requester.id === arac.reviewedBy.id
    ).map(arac => arac.name);

    // Categorize total count of different values for ARAC.state
    const stateCounts = {};
    aracArray.forEach((arac) => {
        stateCounts[arac.state] = (stateCounts[arac.state] || 0) + 1;
    });

    // Duplicate Combination of requestedfor and requestedObject
    const analysisResult = {
        duplicateCombinations: {}
    };

    const combinationMap = {};

    aracArray.forEach((arac) => {
        const combinationKey = `${arac.requestedFor.id}-${arac.requestedObject.id}`;
        if (combinationMap[combinationKey]) {
            combinationMap[combinationKey].count++;
            //analysisResult.duplicateCombinationCount = combinationMap[combinationKey].count++;
            const combinationDetails = combinationMap[combinationKey];
            const name = arac.name;
            combinationDetails.names.push(name);
        } else {
            combinationMap[combinationKey] = {
                names: [arac.name]
            };
        }
    });

    //const duplicateCombinations = {};
    // Store duplicate combinations along with their names
    Object.entries(combinationMap).forEach(([combinationKey, details]) => {
        if (details.names.length > 1) {
            // Check if the combination key already exists in duplicateCombinations
            if (!analysisResult.duplicateCombinations[combinationKey]) {
                // If not, initialize it with an empty array for names
                analysisResult.duplicateCombinations[combinationKey] = {
                    count: details.names.length,
                    names: details.names
                };
            }
            // Push the name to the names array for this combination
            //duplicateCombinations[combinationKey].names.push(details.name);
        }
    });

    // Violated Policy
    const violatedPolicyCounts = {
        nonEmptyCount: 0,
        emptyCount: 0,
        violatedPolicies: {}
    };
    aracArray.forEach((arac) => {
        const sodViolationContext = arac.sodViolationContext;
        if (sodViolationContext && sodViolationContext.violationCheckResult) {
            const violatedPolicies = sodViolationContext.violationCheckResult.violatedPolicies;
            if (violatedPolicies.length > 0) {
                violatedPolicyCounts.nonEmptyCount++;
                violatedPolicies.forEach((policy) => {
                    const key = `${policy.name} - ${arac.requestedFor.name} - ${arac.requestedObject.name}`;
                    violatedPolicyCounts.violatedPolicies[key] =
                        (violatedPolicyCounts.violatedPolicies[key] || 0) + 1;
                });
            } else {
                violatedPolicyCounts.emptyCount++;
            }
        } else {
            violatedPolicyCounts.emptyCount++;
        }
    });


    // Sort top occurrences
    const sortTopOccurrences = (obj) => {
        return Object.entries(obj)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .reduce((acc, [key, value]) => {
                acc[key] = value;
                return acc;
            }, {});
    };

    return {
        totalCount,
        requestTypes,
        topRequesters: sortTopOccurrences(topRequesters),
        topRequestedFor: sortTopOccurrences(topRequestedFor),
        topReviewedBy: sortTopOccurrences(topReviewedBy),
        topRequestedObject: sortTopOccurrences(topRequestedObject),
        requesterEqualsRequestedForCount,
        requesterEqualsReviewedByCount,
        requesterEqualsReviewedByNames,
        stateCounts,
        analysisResult,
        violatedPolicyCounts,
    };
}

function createARCPdf(analysisResult, outputPath) {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Function to print a list of items
    const printList = (title, items) => {
        doc
            .fontSize(12)
            .fillColor("#3366CC")
            .text(title, { underline: true })
            .fillColor("black")
            .moveDown(0.5);

        Object.entries(items).forEach(([item, value]) => {
            doc
                .font("Times-Roman")
                .fontSize(12)
                .text(`${item}: ${value}`)
                .moveDown(0.5);
        });
    };

    // Title
    doc.fontSize(20).text("Access Request Analysis Report", { align: "center" }).moveDown();

    // Print Total Count of Access Request Approvals
    printList("Total Count of Access Request Approvals (ARAC) Completed", {
        "Total Count": analysisResult.totalCount
    });

    // Print Total Count of Different Request Types
    printList("Total Count of Different Request Types", analysisResult.requestTypes);

    // Print Top 5 Occurrence of most ARAC.requester
    printList("Top 5 Occurrence of most ARAC.requester", analysisResult.topRequesters);

    // Print Top 5 Occurrence of most ARAC.requestedFor
    printList("Top 5 Occurrence of most ARAC.requestedFor", analysisResult.topRequestedFor);

    // Print Top 5 Occurrence of most ARAC.reviewedBy
    printList("Top 5 Occurrence of most ARAC.reviewedBy", analysisResult.topReviewedBy);

    // Print Top 5 Occurrence of most ARAC.requestedObject
    printList("Top 5 Occurrence of most ARAC.requestedObject", analysisResult.topRequestedObject);

    // Print Count of ARAC where ARAC.requester == ARAC.requestedFor
    printList("Count of ARAC where ARAC.requester == ARAC.requestedFor", {
        "Count": analysisResult.requesterEqualsRequestedForCount
    });

    printList("Count of ARAC where ARAC.requester == ARAC.reviewedBy", {
        "Count": analysisResult.requesterEqualsReviewedByCount
    });

    // Print List of ARAC names where ARAC.requester == ARAC.reviewedBy
    printList("List of ARAC names where ARAC.requester == ARAC.reviewedBy", {
        "Names": analysisResult.requesterEqualsReviewedByNames.join(', ')
    });

    // Print Categorize total count of different values for ARAC.state
    printList("Categorize total count of different values for ARAC.state", analysisResult.stateCounts);

    // Print Duplicate Combination of requestedfor and requestedObject
    printList("Duplicate Combination of requestedfor and requestedObject", {
        "Count": Object.entries(analysisResult.analysisResult.duplicateCombinations || {}).length
    });

    // Check if duplicateCombinations is defined and not null
    if (analysisResult.analysisResult.duplicateCombinations) {
        Object.entries(analysisResult.analysisResult.duplicateCombinations).forEach(([combination, details]) => {
            doc
                .font("Times-Roman")
                .fontSize(12)
                .text(`Combination: ${combination}, Count: ${details.count}`)
                .text(`Names: ${details.names.join(", ")}`)
                .moveDown(0.5);
        });
    }

    // Print Violated Policy
    doc
        .fontSize(16)
        .fillColor("#3366CC")
        .text("Violated Policy", { underline: true })
        .fillColor("black")
        .moveDown(0.5);

    doc
        .font("Times-Roman")
        .fontSize(12)
        .text(`Non-empty Count: ${analysisResult.violatedPolicyCounts.nonEmptyCount}`)
        .text(`Empty Count: ${analysisResult.violatedPolicyCounts.emptyCount}`)
        .moveDown(0.5);

    Object.entries(analysisResult.violatedPolicyCounts.violatedPolicies).forEach(([policy, count]) => {
        doc
            .font("Times-Roman")
            .fontSize(12)
            .text(`${policy}: ${count}`)
            .moveDown(0.5);
    });

    // End document and handle stream finish event
    doc.end();
    stream.on("finish", () =>
        console.log("Access Request Analysis Report written to output.pdf")
    );
}


module.exports = { analyzeARAC, createARCPdf };