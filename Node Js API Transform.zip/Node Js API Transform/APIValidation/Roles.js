// Author: Uday Reddy

// Summary:
// This module provides functions to analyze and generate a PDF report for roles data. The `analyzeRoles` function takes an array of roles, counts various statistics such as approval schemes, enabled and requestable statuses, membership counts, top identities, top owners, duplicate access profiles and entitlements, and owner type occurrences, and returns the analysis result. The `createRolesResultP

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

const analyzeRoles = (roles) => {
    const results = {
        totalCount: roles.length,
        accessRequestConfigApprovalSchemes: {
            count0: 0,
            count1: 0,
            countMoreThan1: 0,
            listCount0: [],
            zero: [], // Initialize as an empty array
        },
        revocationRequestConfigApprovalSchemes: {
            count0: 0,
            count1: 0,
            countMoreThan1: 0,
            listCount0: [],
            zero: [], // Initialize as an empty array
        },
        enabledAndRequestable: {
            enabledTrue: 0,
            enabledFalse: 0,
            requestableTrue: 0,
            requestableFalse: 0,
        },
        identicalAccessProfilesAndEntitlements: [],
        ownerTypeOccurrences: {},
        identitiesCount0: [],
        topIdentitiesCount: [],
        topOwners: [],
        duplicateAccessProfilesAndEntitlements: {},
        identitiesCountNull: [],
        identitiesCountZero: [],
    };

    roles.forEach((role) => {
        // Count approval schemes in access request config
        const accessRequestConfigApprovalSchemeCount = role.accessRequestConfig.approvalSchemes.length;
        if (accessRequestConfigApprovalSchemeCount === 0) {
            results.accessRequestConfigApprovalSchemes.count0++;
            results.accessRequestConfigApprovalSchemes.listCount0.push({ id: role.id, name: role.name });
        } else if (accessRequestConfigApprovalSchemeCount === 1) {
            results.accessRequestConfigApprovalSchemes.count1++;
        } else {
            results.accessRequestConfigApprovalSchemes.countMoreThan1++;
        }

        // Count approval schemes in revocation request config
        const revocationRequestConfigApprovalSchemeCount = role.revocationRequestConfig.approvalSchemes.length;
        if (revocationRequestConfigApprovalSchemeCount === 0) {
            results.revocationRequestConfigApprovalSchemes.count0++;
            results.revocationRequestConfigApprovalSchemes.listCount0.push({ id: role.id, name: role.name });
        } else if (revocationRequestConfigApprovalSchemeCount === 1) {
            results.revocationRequestConfigApprovalSchemes.count1++;
        } else {
            results.revocationRequestConfigApprovalSchemes.countMoreThan1++;
        }

        // Count enabled and requestable roles
        if (role.enabled) {
            results.enabledAndRequestable.enabledTrue++;
        } else {
            results.enabledAndRequestable.enabledFalse++;
        }
        if (role.requestable) {
            results.enabledAndRequestable.requestableTrue++;
        } else {
            results.enabledAndRequestable.requestableFalse++;
        }



        // Iterate every GRO, find GRO.identities, print GRO.name and GRO.id for every GRO.membership.count == 0 or null
        if (!role.membership || role.membership.count === 0) {
            results.identitiesCountNull.push({ id: role.id, name: role.name });
        }

        // Iterate every GRO, find GRO.identities, print GRO.name and GRO.id for every GRO.membership.identies.count == 0 or null
        if (!role.membership || !role.membership.identities) {
            results.identitiesCountZero.push({ id: role.id, name: role.name });
        }

        // Top 5 identities count
        results.topIdentitiesCount.push({ id: role.id, name: role.name, count: role.membership && role.membership.identities ? role.membership.identities.length : 0 });

        // Top 5 owners
        if (role.owner && role.owner.id) {
            const ownerIndex = results.topOwners.findIndex((owner) => owner.id === role.owner.id);
            if (ownerIndex !== -1) {
                results.topOwners[ownerIndex].count++;
            } else {
                results.topOwners.push({ id: role.owner.id, name: role.owner.name, count: 1 });
            }
            results.topOwners.sort((a, b) => b.count - a.count);
            if (results.topOwners.length > 5) {
                results.topOwners.pop();
            }
        }

        // Duplicate access profiles and entitlements
        const key = `${role.accessProfiles.map((ap) => ap.name).sort().join('_')}_${role.entitlements.map((e) => e.name).sort().join('_')}`;
        if (results.duplicateAccessProfilesAndEntitlements.hasOwnProperty(key)) {
            results.duplicateAccessProfilesAndEntitlements[key].push(role.id);
        } else {
            results.duplicateAccessProfilesAndEntitlements[key] = [role.id];
        }

        // Count occurrences of GRO.owner.type
        if (role.owner && role.owner.type) {
            results.ownerTypeOccurrences[role.owner.type] = (results.ownerTypeOccurrences[role.owner.type] || 0) + 1;
        }
    });

    return results;
};

const createRolesResultPdf = (results, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);

    doc.pipe(stream);
    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    // Title
    doc.fontSize(24).fillColor("#333333").font("Times-Roman").text("Roles Analysis Report", { align: "center" }).moveDown();

    // Total Count - GRO
    doc.fontSize(18).fillColor("#333333").font("Times-Roman").text(`Total Count of Roles: ${results.totalCount}`).moveDown();

    // Total Count - GRO.accessRequestConfig.approvalSchemes ==0, ==1 and >1
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Access Request Config Approval Schemes:");
    doc.fillColor("#008000").font("Times-Roman").text(`Count 0: ${results.accessRequestConfigApprovalSchemes.count0}`);
    doc.fillColor("#008000").text(`Count 1: ${results.accessRequestConfigApprovalSchemes.count1}`);
    doc.fillColor("#008000").text(`Count More Than 1: ${results.accessRequestConfigApprovalSchemes.countMoreThan1}`).moveDown();

    // List GRO.accessRequestConfig.approvalSchemes ==0; print GRO.id and name 
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Roles with Access Request Config Approval Schemes == 0:");
    results.accessRequestConfigApprovalSchemes.listCount0.forEach((gro) => {
        doc.fillColor("#008000").font("Times-Roman").text(`${gro.name}: ${gro.id}`);
    });
    doc.moveDown();

    // Total Count - GRO.revocationRequestConfig.approvalSchemes ==0, ==1 and >1
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Revocation Request Config Approval Schemes:");
    doc.fillColor("#008000").font("Times-Roman").text(`Count 0: ${results.revocationRequestConfigApprovalSchemes.count0}`);
    doc.fillColor("#008000").text(`Count 1: ${results.revocationRequestConfigApprovalSchemes.count1}`);
    doc.fillColor("#008000").text(`Count More Than 1: ${results.revocationRequestConfigApprovalSchemes.countMoreThan1}`).moveDown();

    // List GRO.revocationRequestConfig.approvalSchemes ==0; print GRO.id and name 
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Roles with Revocation Request Config Approval Schemes == 0:");
    results.revocationRequestConfigApprovalSchemes.listCount0.forEach((gro) => {
        doc.fillColor("#008000").font("Times-Roman").text(`${gro.name}: ${gro.id}`);
    });
    doc.moveDown();

    // Total Count - GRO.enabled true; false
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Total Count of Enabled and Requestable:");
    doc.fillColor("#008000").font("Times-Roman").text(`Enabled True: ${results.enabledAndRequestable.enabledTrue}`);
    doc.fillColor("#008000").text(`Enabled False: ${results.enabledAndRequestable.enabledFalse}`).moveDown();

    // Total Count - GRO.requestable true; false
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Total Count of Requestable:");
    doc.fillColor("#008000").font("Times-Roman").text(`Requestable True: ${results.enabledAndRequestable.requestableTrue}`);
    doc.fillColor("#008000").text(`Requestable False: ${results.enabledAndRequestable.requestableFalse}`).moveDown();

    // Iterate every GRO, find GRO.identities, print GRO.name and GRO.id for every GRO.membership.count == 0 or null
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Roles with Membership Count Null:");
    results.identitiesCountNull.forEach((gro) => {
        doc.fillColor("#008000").font("Times-Roman").text(`Name: ${gro.name}, ID: ${gro.id}`);
    });
    doc.moveDown();

    // Iterate every GRO, find GRO.identities, print GRO.name and GRO.id for every GRO.membership.identies.count == 0 or null
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Roles with Zero Identity Count:");
    results.identitiesCountZero.forEach((gro) => {
        doc.fillColor("#008000").font("Times-Roman").text(`Name: ${gro.name}, ID: ${gro.id}`);
    });
    doc.moveDown();


    // Iterate every GRO, find GRO.membership.identities, for every GRO.membership.identities.count == (top 5 count) - print GRO.name and  GRO.id   and the count
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Top Identities Count:");
    results.topIdentitiesCount.forEach((gro) => {
        doc.fillColor("#008000").font("Times-Roman").text(` ${gro.name}: ${gro.id}, Count: ${gro.count}`);
    });
    doc.moveDown();

    // Iterate every GRO, find GRO.owner - Top 5 occurences of GRO.owner.id - print GRO.owner.name and id and also print count
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Top Owners:");
    results.topOwners.forEach((owner) => {
        doc.fillColor("#008000").font("Times-Roman").text(` ${owner.name}: ${owner.id}`);
    });
    doc.moveDown();

    // Iterate GRO - For every combination of duplicate GRO.accessProfiles and GRO.entitlements; print GRO.accessProfile.name, GRO.entitlements.name and all the GRO.id where they are occurred
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Duplicate Access Profiles and Entitlements:");
    Object.entries(results.duplicateAccessProfilesAndEntitlements).forEach(([key, value]) => {
        const [accessProfile, entitlement] = key.split('_');
        doc.fillColor("#008000").font("Times-Roman").text(`Access Profile: ${accessProfile}, Entitlements: ${entitlement}`);
        doc.fillColor("#008000").font("Times-Roman").text(`Roles: ${value.join(", ")}`);
    });
    doc.moveDown();

    // Total occurrences count of GRO.owner.type
    doc.fontSize(16).fillColor("#333333").font("Times-Roman").text("Owner Type Occurrences:");
    Object.entries(results.ownerTypeOccurrences).forEach(([ownerType, count]) => {
        doc.fillColor("#008000").font("Times-Roman").text(`${ownerType}: ${count}`);
    });
    doc.moveDown();

    doc.end();

    console.log("PDF report created successfully!");
};



module.exports = { analyzeRoles, createRolesResultPdf };
