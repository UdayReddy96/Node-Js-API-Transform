// Author: Uday Reddy

// Summary:
// This module provides functions to analyze and generate a PDF report for requestable objects (GRO). The `analyzeReqObjResult` function takes an array of GRO structures, counts the total number of objects and the occurrences of each type, and returns the analysis result. The `createReqObjResultPdf` function generates a PDF report based on the provided analysis result, including a title, total count of objects, and details of each object type and its occurrence count.


const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

function analyzeReqObjResult(groStructure) {
    // Initialize counters
    let totalCount = 0;
    const typeOccurences = {};

    // Loop through each GRO object
    groStructure.forEach(gro => {
        // Increment total count
        totalCount++;

        // Check if GRO type already exists in typeOccurences object
        if (typeOccurences.hasOwnProperty(gro.type)) {
            // If exists, increment the count
            typeOccurences[gro.type]++;
        } else {
            // If not, initialize with count 1
            typeOccurences[gro.type] = 1;
        }
    });

    // Return the analysis result
    return { totalCount, typeOccurences };
}



const createReqObjResultPdf = (analysisResult, outputPath) => {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);

    doc.pipe(stream);

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.text('requestable-objects Analysis Report', { align: 'center', underline: true });

    // Total Count
    doc.text('\nTotal Count:', { underline: true });
    doc.text(`${analysisResult.totalCount}`);

    // Type Occurrences
    doc.text('\nType Occurrences:', { underline: true });
    for (const type in analysisResult.typeOccurences) {
        doc.text(`${type}: ${analysisResult.typeOccurences[type]}`);
    }

    doc.end();

    console.log(`PDF created successfully at ${outputPath}`);
};

module.exports = { analyzeReqObjResult, createReqObjResultPdf };
