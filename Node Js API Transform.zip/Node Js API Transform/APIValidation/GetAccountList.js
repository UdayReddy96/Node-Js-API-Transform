// Author: Uday Reddy

// Summary:
// This module contains functions to analyze Get Account List (GAL) data and generate a PDF report based on the analysis. The `analyseGAL` function takes GAL data and an authentication token, then analyzes the data to generate various statistics. These statistics include total counts, counts by source, counts of authoritative GALs, counts of disabled and locked GALs, counts of uncorrelated and manually correlated GALs, and details of identities with authoritative set to false. The `createGALPdf` function generates a PDF report based on the analysis results. It includes a title, total count of GALs, counts by source, counts of authoritative GALs, details of source sets for authoritative and non-authoritative GALs, details of identities with authoritative set to false, counts of disabled and locked GALs, counts of uncorrelated and manually correlated GALs, and details of uncorrelated GALs including their names and source names.

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

// GAL

const analyseGAL = async (gal, token) => {
    const result = {
        galTotalCount: 0,
        totalCountBySource: {},
        authoritativeCount: { true: 0, false: 0 },
        sourceSetsForAuthoritative: new Set(),
        sourceSetsForNonAuthoritative: new Set(),
        disabledCount: { true: 0, false: 0 },
        lockedCount: { true: 0, false: 0 },
        uncorrelatedCount: { true: 0, false: 0 },
        manuallyCorrelatedCount: { true: 0, false: 0 },
        uncorrelatedDetails: [],
        identitiesWithFalseAuthoritative: [] // New property to store identities with authoritative == false
    };

    const { fetchApiData } = require("../app");

    result.galTotalCount = gal.length;

    for (const entry of gal) {
        // Segregate by sourceId and sourceName
        result.totalCountBySource[`${entry.sourceId} - ${entry.sourceName}`] = (result.totalCountBySource[`${entry.sourceId} - ${entry.sourceName}`] || 0) + 1;

        // Total Count Authoritative by true and false
        result.authoritativeCount[entry.authoritative ? 'true' : 'false']++;

        // For Every GAL.authoritative == true, finding different sets of Source ID
        if (entry.authoritative) {
            result.sourceSetsForAuthoritative.add(entry.sourceName);
        } else {
            result.sourceSetsForNonAuthoritative.add(entry.sourceName);
            const response = await fetchApiData(`/beta/identities/${entry.identityId}`, token);
            // Process the response if needed
            const identity = response[0];
            result.identitiesWithFalseAuthoritative.push({ name: identity.name, id: identity.id }); // Add identity to the array
        }

        // Total Count disabled by true and false
        result.disabledCount[entry.disabled ? 'true' : 'false']++;

        // Total Count locked by true and false
        result.lockedCount[entry.locked ? 'true' : 'false']++;

        // Total Count uncorrelated by true and false
        result.uncorrelatedCount[entry.uncorrelated ? 'true' : 'false']++;

        // Total Count manuallyCorrelated by true and false
        result.manuallyCorrelatedCount[entry.manuallyCorrelated ? 'true' : 'false']++;

        // For every GAL.uncorrelated == true, print GAL.name, GAL.sourcename
        if (entry.uncorrelated) {
            result.uncorrelatedDetails.push({ name: entry.name, sourceName: entry.sourceName });
        }
    }

    return result;
};

const createGALPdf = (galAnalysisResult, outputPath) => {
    const doc = new PDFDocument();
    const fs = require("fs");
    doc.pipe(fs.createWriteStream(outputPath));

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.text('Get Account List (GAL) Analysis', { align: 'center', underline: true });


    doc.text(`Total count of Get account list: ${galAnalysisResult.galTotalCount}`)

    // Total Count by GAL.sourceId and sourceName
    doc.text('Total Count by Source:', { underline: true });
    for (const source in galAnalysisResult.totalCountBySource) {
        doc.text(`${source}: ${galAnalysisResult.totalCountBySource[source]}`);
    }

    // Total Count Authoritative
    doc.text('\nTotal Count Authoritative:');
    doc.text(`True: ${galAnalysisResult.authoritativeCount.true}`);
    doc.text(`False: ${galAnalysisResult.authoritativeCount.false}`);

    // For Every GAL.authoritative == true, finding different sets of Source ID
    doc.text('\nDifferent Sets of Source ID for Authoritative GAL:');
    galAnalysisResult.sourceSetsForAuthoritative.forEach(sourceName => {
        doc.text(sourceName);
    });

    doc.text('\nDifferent Sets of Source ID for Non Authoritative GAL:');
    galAnalysisResult.sourceSetsForNonAuthoritative.forEach(sourceName => {
        doc.text(sourceName);
    });

    // Print Identities with authoritative == false
    doc.text('\nIdentities with authoritative == false:');
    galAnalysisResult.identitiesWithFalseAuthoritative.forEach(identity => {
        doc.text(`Name: ${identity.name}, ID: ${identity.id}`);
    });

    // Total Count disabled
    doc.text('\nTotal Count Disabled:');
    doc.text(`True: ${galAnalysisResult.disabledCount.true}`);
    doc.text(`False: ${galAnalysisResult.disabledCount.false}`);

    // Total Count locked
    doc.text('\nTotal Count Locked:');
    doc.text(`True: ${galAnalysisResult.lockedCount.true}`);
    doc.text(`False: ${galAnalysisResult.lockedCount.false}`);

    // Total Count uncorrelated
    doc.text('\nTotal Count Uncorrelated:');
    doc.text(`True: ${galAnalysisResult.uncorrelatedCount.true}`);
    doc.text(`False: ${galAnalysisResult.uncorrelatedCount.false}`);

    // Total Count manuallyCorrelated
    doc.text('\nTotal Count Manually Correlated:');
    doc.text(`True: ${galAnalysisResult.manuallyCorrelatedCount.true}`);
    doc.text(`False: ${galAnalysisResult.manuallyCorrelatedCount.false}`);

    // For every GAL.uncorrelated == true, print GAL.name, GAL.sourcename
    doc.text('\nDetails of Uncorrelated Get Account List (GAL):');
    galAnalysisResult.uncorrelatedDetails.forEach(entry => {
        doc.text(`Name: ${entry.name}, Source Name: ${entry.sourceName}`);
    });



    doc.end();

    console.log(`PDF created successfully at ${outputPath}`);
};



module.exports = { analyseGAL, createGALPdf }