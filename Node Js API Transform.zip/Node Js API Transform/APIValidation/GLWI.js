// Author: Uday Reddy

// Summary:
// This module contains functions to analyze and generate a PDF report for work-item data. The `analyzeGLWI` function analyzes the provided work-item data, counting the total number of work-items and occurrences of different values for the state attribute. The `generateGLWIPDF` function generates a PDF report based on the analysis result, including a title, total count of work-items, and the total occurrences count of different values for the work-item state.

const PDFDocument = require("pdfkit");
const fs = require("fs");
const _logger = require("../Logger");

function analyzeGLWI(glwiData) {
    const result = {
        totalCount: glwiData.length,
        stateOccurrences: {}
    };

    // Count occurrences of different values for GLWI.state
    glwiData.forEach(item => {
        const state = item.state;
        if (state) {
            if (result.stateOccurrences[state]) {
                result.stateOccurrences[state]++;
            } else {
                result.stateOccurrences[state] = 1;
            }
        }
    });

    return result;
}



function generateGLWIPDF(glwiData, outputPath) {
    const analysisResult = glwiData;

    const doc = new PDFDocument();
    doc.pipe(fs.createWriteStream(outputPath));

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    // Title
    doc.fontSize(20).fillColor('#333333').text('work-items Analysis Report', { align: 'center' });

    // Add spacing
    doc.moveDown();

    // Total Count - GLWI.count
    doc.fontSize(16).fillColor('#333333').text('Total Count of work-items:', { underline: true });
    doc.fontSize(12).fillColor('#666666').text(`${analysisResult.totalCount}`);

    // Add spacing
    doc.moveDown();

    // Total occurrences count of different values for GLWI.state
    doc.fontSize(16).fillColor('#333333').text('Total occurrences count of different values for work-items.state:', { underline: true });
    Object.entries(analysisResult.stateOccurrences).forEach(([state, count]) => {
        doc.fontSize(12).fillColor('#666666').text(`${state}: ${count}`);
    });

    doc.end();
}


module.exports = { analyzeGLWI, generateGLWIPDF };