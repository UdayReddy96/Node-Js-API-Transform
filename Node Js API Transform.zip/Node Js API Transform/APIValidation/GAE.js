// Author: Uday Reddy

// Summary:
// This module provides functions to fetch entitlement data from an API endpoint and generate a PDF report based on the fetched data. The `fetchEntitlementsAndGeneratePDF` function fetches entitlement data from the specified endpoint using an authentication token. It then processes the data to extract unique source IDs and fetches additional data for each unique source ID. Finally, it returns an array of key-value pairs containing information about each data source. The `generateGAESourcePDF` function takes the fetched data and generates a PDF report with the title "GAESource Data Processing". It iterates through the data array and prints each key-value pair, including source ID, source name, and count, providing a summarized view of the entitlement data for each data source.

const axios = require("axios");
const fs = require("fs");
const PDFDocument = require("pdfkit");
const config = require("../config");


async function fetchEntitlementsAndGeneratePDF(token) {
    try {
        let data = []; // Array to store key-value pairs

        const { fetchApiData } = require("../app");
        // Fetch data from the /entitlements endpoint to get the IDs
        const entitlementsResponse = await fetchApiData('/beta/entitlements', token);
        const entitlements = entitlementsResponse.data;

        // Extract unique source IDs
        const sourceIds = new Set();
        entitlements.forEach(entitlement => {
            if (entitlement.source && entitlement.source.id) {
                sourceIds.add(entitlement.source.id);
            }
        });

        // Fetch data for each unique source ID and populate data array
        for (const sourceId of sourceIds) {
            const sourceResponse = await fetchApiData(`/v3/accounts/${sourceId}/entitlements`, token);
            const sourceEntitlements = sourceResponse.data;

            // Push key-value pairs to data array
            data.push({
                sourceId,
                sourceName: sourceEntitlements.source.name,
                count: sourceEntitlements.length
            });
        }

        return data;

    } catch (error) {
        console.error("Error fetching data or generating PDF:", error);
    }
}

async function generateGAESourcePDF(data, outputPath) {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);
    doc.pipe(stream);

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Title
    doc.fontSize(20).text('GAESource Data Processing', { align: 'center' }).moveDown();

    // Add spacing
    doc.moveDown();

    // Loop through data and print each key-value pair
    data.forEach(entry => {
        doc.fontSize(16).text(`Source ID: ${entry.sourceId}`, { align: 'left' });
        doc.fontSize(16).text(`Source Name: ${entry.sourceName}`, { align: 'left' });
        doc.fontSize(16).text(`Count: ${entry.count}`, { align: 'left' });
        doc.fontSize(16).text("----------------------------------", { align: 'left' });
        // Add spacing
        doc.moveDown();
    });

    doc.end();
}


module.exports = { fetchEntitlementsAndGeneratePDF, generateGAESourcePDF };