// Author: Uday Reddy

// Summary:
// This module provides functions to process and generate a PDF report for List of Beta Identities (LBI) data. The `processLBI` function processes the provided LBI data, counting the total number of identities and filtering out non-authoritative identities. The `createLBIPDF` function generates a PDF report based on the processed data, including a title, total count of identities, and details of non-authoritative identities.

const fs = require('fs');
const PDFDocument = require('pdfkit');
const _logger = require("../Logger");

function processLBI(LBI) {
    const totalCount = LBI.length;
    const nonAuthoritativeIdentities = LBI.filter(item => item.identityStatus !== "AUTHORITATIVE");

    return {
        totalCount,
        nonAuthoritativeIdentities
    };
}


function createLBIPDF(data, outputPath) {
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(outputPath);

    doc.pipe(stream);

    // Set font size and color
    // Set font and font size
    doc.font('Times-Roman').fontSize(12);

    // Add title
    doc.text('Processed List of Beta Identities(LBI) Data', { align: 'center', underline: true });

    // Add total count
    doc.moveDown();
    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    doc.text(`Total Count: ${data.totalCount}`);

    // Add non-authoritative identities
    doc.moveDown();
    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    doc.text('Non-Authoritative Identities:', { underline: true });

    // Set font and font size
    doc.font('Times-Roman').fontSize(12);
    data.nonAuthoritativeIdentities.forEach((identity, index) => {
        doc.moveDown();
        doc.text(`Identity ${index + 1}:`);
        doc.text(`Name: ${identity.name}`);
        doc.text(`Alias: ${identity.alias}`);
        // Add more fields as needed
    });

    // Finalize PDF
    doc.end();

    console.log(`PDF generated successfully: ${outputPath}`);
}


module.exports = { processLBI, createLBIPDF };